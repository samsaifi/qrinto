{{-- ═══════════════════════════════════════════════════════════════════════
     Four-Canvas Customizer (Desktop PC Version) - DRY Refactored
     Uses shared partials + customizer-base.js
     - Four independent canvases (frame_image, sample_image, background_image, overlay_image)
     - Left Floating Dock: Page 1–4 circle buttons + Templates & Layers drawers
     - Right Floating Dock: Photo, Text, Color, Fonts, Delete, Add to Cart
     ═══════════════════════════════════════════════════════════════════════ --}}

@extends('layouts.quick-flow-pc')
@section('title', 'Customize Your ' . $product->name . ' | Qrinto Online Print Studio')
@section('meta_description',
    'Customize ' .
    $product->name .
    ' online with Qrinto real-time design studio. Add custom
    text, photos, colors, and layers with instant store pickup.')
@section('meta_keywords', 'customize ' . strtolower($product->name) . ', online print editor, custom ' .
    strtolower($product->name) . ' design, Qrinto studio')
@section('canonical_url', url()->current())
@section('og_type', 'product')
@section('og_title', 'Customize Your ' . $product->name . ' | Qrinto Online Print Studio')
@section('og_description',
    'Customize ' .
    $product->name .
    ' online with Qrinto real-time design studio. Add custom
    text, photos, colors, and layers with instant store pickup.')
@section('og_image', asset('logo/Qrinto-logo-small.png'))

@push('styles')
    @include('quick-flow-pc.partials.customizer-styles')
    @include('quick-flow-pc.partials.customizer-fonts')
@endpush

@section('content')
    @php
        $lpo = $localPrintOverrides ?? null;
        $noOfPages = $lpo ? (int) $lpo['noOfPages'] : (int) ($product->no_of_pages ?? 1);
        if ($noOfPages <= 1) {
            $slots = [
                'frame_image' => 'Page 1',
            ];
        } elseif ($noOfPages == 2) {
            $slots = [
                'frame_image' => 'Page 1',
                'sample_image' => 'Page 2',
            ];
        } else {
            $slots = [
                'frame_image' => 'Page 1',
                'sample_image' => 'Page 2',
                'background_image' => 'Page 3',
                'overlay_image' => 'Page 4',
            ];
        }

        $blankCanvas =
            'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="%2394a3b8" stroke-width="1.5"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/><circle cx="9" cy="9" r="2"/></svg>';

        $emptyCanvas = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"/>';

        if ($lpo) {
            $imageTypes = [];
            foreach ($slots as $field => $label) {
                $imageTypes[$field] = ['label' => $label, 'url' => $emptyCanvas];
            }
        } else {
            $galleryImages = $product->images->values();
            $galleryIndex = 0;
            $fallbackUrl =
                $product->featured_image_url ??
                ($product->sample_image_url ??
                    ($product->frame_image_url ?? ($product->background_image_url ?? $blankCanvas)));
            $imageTypes = [];
            foreach ($slots as $field => $label) {
                $url = $product->{$field . '_url'};
                if (!$url && isset($galleryImages[$galleryIndex])) {
                    $url = \App\Models\Product::formatStorageUrl($galleryImages[$galleryIndex]->image_path);
                    $galleryIndex++;
                }
                if (!$url) {
                    $url = $fallbackUrl;
                }
                $imageTypes[$field] = ['label' => $label, 'url' => $url];
            }
        }

        $maskData = $product->mask_data ?? [];
        if (is_string($maskData)) {
            $maskData = json_decode($maskData, true) ?? [];
        }
        if ($lpo) {
            $maskData = [];
            foreach ($slots as $field => $label) {
                $maskData[$field] = [
                    'enabled' => true,
                    'canvasWidth' => $lpo['canvasWidth'],
                    'canvasHeight' => $lpo['canvasHeight'],
                ];
            }
        }
        $flowData = session('quick_flow_data', []);

        $bcStoreName =
            session('active_store_name') ??
            ((session('active_store_id') ? \App\Models\Store::find(session('active_store_id'))?->name : null) ??
                ($product->store->name ?? (null ?? ($flowData['store_name'] ?? 'Store'))));

        $bcProductType =
            $flowData['type_name'] ?? ($product->productType->name ?? ($flowData['category_name'] ?? 'Product Type'));

        $bcTypeSlug = $flowData['type_slug'] ?? ($product->productType->slug ?? null);

        $bcPageSizeSide =
            $flowData['size_name'] ??
            ($flowData['size_title'] ??
                (null ??
                    ((isset($flowData['size_width'], $flowData['size_height'])
                        ? $flowData['size_width'] . '×' . $flowData['size_height'] . ($flowData['size_unit'] ?? '')
                        : null) ??
                        ($product->no_of_pages
                            ? ($product->no_of_pages == 1
                                ? 'Single Side'
                                : ($product->no_of_pages == 2
                                    ? 'Double Side'
                                    : $product->no_of_pages . ' Pages'))
                            : 'Standard Size'))));

        $bcTemplateName = $product->name ?? 'Custom Template';
    @endphp

    <div id="customizer-app">

        {{-- ── Breadcrumb Navigation ── --}}
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-1.5">
            {{-- Desktop breadcrumb (full) --}}
            <nav class="cust-breadcrumb cust-breadcrumb-desktop flex items-center flex-wrap gap-2 text-xs font-semibold">
                <a href="{{ route('flow.index') }}" class="text-slate-500 hover:text-brand-600 transition-colors">Home</a>
                <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-400 shrink-0"></i>
                <span class="text-slate-500 font-medium">{{ $bcStoreName }}</span>
                <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-400 shrink-0"></i>
                @if ($bcTypeSlug)
                    <a href="{{ route('flow.category', $bcTypeSlug) }}"
                        class="text-slate-500 hover:text-brand-600 transition-colors">{{ $bcProductType }}</a>
                @else
                    <span class="text-slate-500 font-medium">{{ $bcProductType }}</span>
                @endif
                <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-400 shrink-0"></i>
                <span class="text-slate-500 font-medium">{{ $bcPageSizeSide }}</span>
                <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-400 shrink-0"></i>
                <span class="text-slate-900 font-extrabold max-w-xs truncate" title="{{ $bcTemplateName }}">{{ $bcTemplateName }}</span>
            </nav>
            {{-- Mobile breadcrumb (abbreviated) --}}
            <nav class="cust-breadcrumb cust-breadcrumb-mobile items-center gap-1.5 text-[10px] font-semibold" style="display:none;">
                <a href="{{ route('flow.index') }}" class="text-slate-500 hover:text-brand-600 transition-colors shrink-0">Home</a>
                <i data-lucide="chevron-right" class="w-3 h-3 text-slate-400 shrink-0"></i>
                <span class="text-slate-500 font-medium shrink-0">{{ $bcPageSizeSide }}</span>
                <i data-lucide="chevron-right" class="w-3 h-3 text-slate-400 shrink-0"></i>
                <span class="text-slate-900 font-extrabold max-w-[160px] truncate" title="{{ $bcTemplateName }}">{{ $bcTemplateName }}</span>
            </nav>
        </div>

        {{-- ── 1. STUDIO EDITOR WORKSPACE (DOTTED BACKGROUND) ── --}}
        <section class="cust-workspace w-full relative py-3 px-3 sm:px-6 border-b border-slate-200/80"
            style="background-color: #f8fafc; background-image: radial-gradient(#cbd5e1 1.5px, transparent 1.5px); background-size: 24px 24px;">

            <div class="max-w-7xl mx-auto">

                {{-- Studio Independent Floating Layout --}}
                <div class="cust-workspace-inner relative w-full min-h-[70vh] flex items-center justify-center">

                    {{-- ═══ LEFT: ABSOLUTE FLOATING VERTICAL TOOL DOCK ═══ --}}
                    <div
                        class="cust-left-dock absolute left-1 lg:left-4 top-1/2 -translate-y-1/2 grid grid-cols-2 gap-x-2 gap-y-3 justify-items-center items-start shrink-0 z-30 py-3 px-2 bg-white/50 backdrop-blur-sm rounded-3xl border border-slate-200/60 shadow-sm">

                        {{-- Page Circle Buttons (Only if product has > 1 page) --}}
                        @if (count($imageTypes) > 1)
                            @foreach ($imageTypes as $key => $img)
                                @php
                                    $config = $maskData[$key] ?? [];
                                    $enabled = ($config['enabled'] ?? true) !== false;
                                    $isFirst = $loop->first;
                                @endphp
                                <button type="button" onclick="customizer.switchCanvas('{{ $key }}')"
                                    class="thumb-nav-btn group flex flex-col items-center gap-1 cursor-pointer {{ !$enabled ? 'disabled-tab' : '' }}"
                                    data-key="{{ $key }}" title="{{ $img['label'] }}">
                                    <div id="page-btn-{{ $key }}"
                                        class="w-12 h-12 rounded-2xl bg-white {{ $isFirst ? 'text-brand-600 shadow-md border-2 border-brand-500 scale-105' : 'text-slate-500 shadow-2xs border border-slate-200/90 group-hover:text-brand-600 group-hover:border-brand-300 group-hover:scale-105' }} flex items-center justify-center transition-all duration-200 relative {{ !$enabled ? 'opacity-70' : '' }}">
                                        <i data-lucide="file-text" class="w-5 h-5"></i>
                                        @if (!$enabled)
                                            <div class="thumb-lock-badge absolute -top-1 -right-1 w-4 h-4 rounded-full bg-slate-700 text-white flex items-center justify-center border border-white shadow-2xs z-20"
                                                title="Canvas Locked">
                                                <i data-lucide="lock" class="w-2.5 h-2.5"></i>
                                            </div>
                                        @endif
                                    </div>
                                    <span
                                        class="text-[10px] {{ $isFirst ? 'font-black text-brand-600' : 'font-bold text-slate-500 group-hover:text-brand-600' }} transition-colors">
                                        Page {{ $loop->iteration }}
                                    </span>
                                </button>
                            @endforeach

                            <div id="left-dock-divider" class="col-span-2 w-full h-px bg-slate-200/80 my-0.5"></div>
                        @endif

                        {{-- Templates Button --}}
                        <button type="button" id="templates-dock-trigger" onclick="toggleTemplatesDrawer()"
                            class="group flex flex-col items-center gap-1 cursor-pointer" title="Ready-Made Templates">
                            <div id="templates-dock-btn"
                                class="w-12 h-12 rounded-2xl bg-white shadow-2xs border border-slate-200/90 flex items-center justify-center text-brand-500 group-hover:bg-brand-600 group-hover:text-white group-hover:scale-105 transition-all duration-200">
                                <i data-lucide="layout-template" class="w-5 h-5"></i>
                            </div>
                            <span
                                class="text-[10px] font-black text-slate-600 group-hover:text-brand-600 transition-colors">Templates</span>
                        </button>

                        {{-- Layers Button --}}
                        <button type="button" id="layers-dock-trigger" onclick="toggleLayersDrawer()"
                            class="group flex flex-col items-center gap-1 cursor-pointer" title="Layers Panel">
                            <div id="layers-dock-btn"
                                class="w-12 h-12 rounded-2xl bg-white shadow-2xs border border-slate-200/90 flex items-center justify-center text-slate-600 group-hover:bg-brand-600 group-hover:text-white group-hover:scale-105 transition-all duration-200">
                                <i data-lucide="layers" class="w-5 h-5"></i>
                            </div>
                            <span
                                class="text-[10px] font-black text-slate-600 group-hover:text-brand-600 transition-colors">Layers</span>
                        </button>

                    </div>

                    {{-- Shared Drawers (Templates, Layers, Typography, Shapes, QR) --}}
                    @include('quick-flow-pc.partials.customizer-drawers')
                    @include('quick-flow-pc.partials.customizer-context-menu')

                    {{-- ═══ CENTER: CENTERED CANVAS WORKSPACE ═══ --}}
                    <div class="w-full flex flex-col items-center justify-center min-w-0 space-y-2">

                        {{-- ── Studio Header Toolbar (Undo, Redo, Alignments, Zoom, Pre-flight) ── --}}
                        <div
                            class="cust-toolbar w-full max-w-6xl bg-white/90 backdrop-blur-md border border-slate-200/90 rounded-2xl p-2.5 shadow-sm flex flex-nowrap items-center justify-between gap-2 overflow-x-auto z-20">
                            {{-- History & Edit --}}
                            <div class="flex items-center gap-1">
                                <button type="button" onclick="customizer.undo()"
                                    class="p-2 text-slate-600 hover:text-brand-600 hover:bg-slate-100 rounded-xl transition-all"
                                    title="Undo (Ctrl+Z)">
                                    <i data-lucide="undo-2" class="w-4 h-4"></i>
                                </button>
                                <button type="button" onclick="customizer.redo()"
                                    class="p-2 text-slate-600 hover:text-brand-600 hover:bg-slate-100 rounded-xl transition-all"
                                    title="Redo (Ctrl+Y)">
                                    <i data-lucide="redo-2" class="w-4 h-4"></i>
                                </button>
                                <div class="w-px h-5 bg-slate-200 mx-1"></div>
                                <button type="button" onclick="customizer.duplicateSelected()"
                                    class="p-2 text-slate-600 hover:text-brand-600 hover:bg-slate-100 rounded-xl transition-all"
                                    title="Duplicate Object (Ctrl+D)">
                                    <i data-lucide="copy" class="w-4 h-4"></i>
                                </button>
                                <button type="button" onclick="customizer.toggleLockSelected()"
                                    class="p-2 text-slate-600 hover:text-amber-600 hover:bg-amber-50 rounded-xl transition-all"
                                    title="Lock / Unlock Object">
                                    <i data-lucide="lock" class="w-4 h-4"></i>
                                </button>

                                <div class="w-px h-5 bg-slate-200 mx-1"></div>

                                {{-- Clear All (multi trash - small faded bin beside a full bin) --}}
                                <button type="button" onclick="customizer.clearAll()"
                                    class="p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-xl transition-all"
                                    title="Clear All Designs">
                                    <span class="inline-flex items-end gap-0.5 align-middle">
                                        <i data-lucide="trash-2" class="w-3 h-3 opacity-50"></i>
                                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                                    </span>
                                </button>

                                {{-- Remove Selected (single trash - only shown when something is selected) --}}
                                <button type="button" id="remove-btn" onclick="customizer.handleRemove()"
                                    class="hidden p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-xl transition-all"
                                    title="Remove Selected">
                                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                                    <span id="remove-btn-text" class="sr-only">Remove</span>
                                </button>
                            </div>

                            {{-- Alignments --}}
                            <div class="cust-toolbar-align flex items-center gap-1 bg-slate-50 p-1 rounded-xl border border-slate-200/60">
                                <button type="button" onclick="customizer.alignSelected('left')"
                                    class="p-1.5 text-slate-500 hover:text-brand-600 hover:bg-white rounded-lg transition-all"
                                    title="Align Left">
                                    <i data-lucide="align-start-vertical" class="w-3.5 h-3.5"></i>
                                </button>
                                <button type="button" onclick="customizer.alignSelected('center')"
                                    class="p-1.5 text-slate-500 hover:text-brand-600 hover:bg-white rounded-lg transition-all"
                                    title="Align Horizontal Center">
                                    <i data-lucide="align-center-vertical" class="w-3.5 h-3.5"></i>
                                </button>
                                <button type="button" onclick="customizer.alignSelected('right')"
                                    class="p-1.5 text-slate-500 hover:text-brand-600 hover:bg-white rounded-lg transition-all"
                                    title="Align Right">
                                    <i data-lucide="align-end-vertical" class="w-3.5 h-3.5"></i>
                                </button>
                                <div class="w-px h-4 bg-slate-200"></div>
                                <button type="button" onclick="customizer.alignSelected('top')"
                                    class="p-1.5 text-slate-500 hover:text-brand-600 hover:bg-white rounded-lg transition-all"
                                    title="Align Top">
                                    <i data-lucide="align-start-horizontal" class="w-3.5 h-3.5"></i>
                                </button>
                                <button type="button" onclick="customizer.alignSelected('middle')"
                                    class="p-1.5 text-slate-500 hover:text-brand-600 hover:bg-white rounded-lg transition-all"
                                    title="Align Vertical Middle">
                                    <i data-lucide="align-center-horizontal" class="w-3.5 h-3.5"></i>
                                </button>
                                <button type="button" onclick="customizer.alignSelected('bottom')"
                                    class="p-1.5 text-slate-500 hover:text-brand-600 hover:bg-white rounded-lg transition-all"
                                    title="Align Bottom">
                                    <i data-lucide="align-end-horizontal" class="w-3.5 h-3.5"></i>
                                </button>
                            </div>

                            {{-- Rotate & Flip --}}
                            <div class="cust-toolbar-rotate flex items-center gap-1">
                                <button type="button" onclick="customizer.rotateSelected(90)"
                                    class="p-2 text-slate-600 hover:text-brand-600 hover:bg-slate-100 rounded-xl transition-all"
                                    title="Rotate 90°">
                                    <i data-lucide="rotate-cw" class="w-4 h-4"></i>
                                </button>
                                <button type="button" onclick="customizer.flipHSelected()"
                                    class="p-2 text-slate-600 hover:text-brand-600 hover:bg-slate-100 rounded-xl transition-all"
                                    title="Flip Horizontal">
                                    <i data-lucide="flip-horizontal" class="w-4 h-4"></i>
                                </button>
                                <button type="button" onclick="customizer.flipVSelected()"
                                    class="p-2 text-slate-600 hover:text-brand-600 hover:bg-slate-100 rounded-xl transition-all"
                                    title="Flip Vertical">
                                    <i data-lucide="flip-vertical" class="w-4 h-4"></i>
                                </button>
                                <div class="w-px h-5 bg-slate-200 mx-1"></div>
                                <button type="button" id="reposition-top-btn"
                                    onclick="customizer.enterImageRepositionMode()"
                                    class="hidden p-2 text-purple-700 bg-purple-100 hover:bg-purple-200 rounded-xl transition-all font-extrabold text-xs flex items-center gap-1.5 shadow-2xs"
                                    title="Reposition Image Inside Shape">
                                    <i data-lucide="move" class="w-4 h-4 text-purple-700"></i>
                                    <span class="hidden sm:inline">Move Image</span>
                                </button>
                                <button type="button" id="group-top-btn" onclick="customizer.groupSelected()"
                                    class="hidden p-2 text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-xl transition-all font-bold text-xs flex items-center gap-1.5 shadow-2xs"
                                    title="Group Selected Objects (Ctrl+G)">
                                    <i data-lucide="folder-plus" class="w-4 h-4 text-indigo-600"></i>
                                    <span class="hidden sm:inline">Group</span>
                                </button>
                                <button type="button" id="ungroup-top-btn" onclick="customizer.ungroupSelected()"
                                    class="hidden p-2 text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-xl transition-all font-bold text-xs flex items-center gap-1.5 shadow-2xs"
                                    title="Ungroup Objects (Ctrl+Shift+G)">
                                    <i data-lucide="folder-minus" class="w-4 h-4 text-amber-600"></i>
                                    <span class="hidden sm:inline">Ungroup</span>
                                </button>
                                <button type="button" id="crop-top-btn" onclick="customizer.enterCropMode()"
                                    class="hidden p-2 text-brand-700 bg-brand-50 hover:bg-brand-100 rounded-xl transition-all font-bold text-xs flex items-center gap-1.5 shadow-2xs"
                                    title="Crop Image">
                                    <i data-lucide="crop" class="w-4 h-4 text-pink-600"></i>
                                    <span class="hidden sm:inline">Crop Image</span>
                                </button>
                                <button type="button" id="mask-top-btn" onclick="toggleShapeMaskDrawer()"
                                    class="hidden p-2  text-gray-700  bg-gray-50 hover: bg-gray-100 rounded-xl transition-all font-bold text-xs flex items-center gap-1.5 shadow-2xs"
                                    title="Mask Image into Shape">
                                    <i data-lucide="shapes" class="w-4 h-4  text-gray-600"></i>
                                    <span class="hidden sm:inline">Shape Mask</span>
                                </button>
                            </div>

                            {{-- Zoom Controls & Pre-flight Quality --}}
                            <div class="cust-toolbar-zoom flex items-center gap-2">
                                <select onchange="customizer.setZoom(this.value)" title="Canvas Zoom Level"
                                    class="bg-slate-50 border border-slate-200 text-slate-700 text-xs font-bold px-2.5 py-1.5 rounded-xl outline-none cursor-pointer">
                                    <option value="1">100% </option>
                                    <option value="1.25">125%</option>
                                    <option value="1.5">150%</option>
                                    <option value="2">200%</option>
                                </select>

                                {{-- 300 DPI Pre-flight Indicator --}}
                                <div id="preflight-badge"
                                    class="flex items-center gap-1.5 px-3 py-1.5 rounded-full  bg-gray-50  text-gray-700 border  border-gray-200/80 text-[11px] font-extrabold shadow-2xs"
                                    title="Print Quality Score">
                                    <i data-lucide="check-circle-2" class="w-3.5 h-3.5  text-gray-600"></i>
                                    <span id="preflight-text">300 DPI Optimal</span>
                                </div>
                            </div>
                        </div>

                        {{-- Mobile Page Switcher (horizontal strip, hidden on desktop via CSS) --}}
                        @if (count($imageTypes) > 1)
                        <div class="cust-mobile-pages" style="display:none;">
                            @foreach ($imageTypes as $key => $img)
                                @php
                                    $config = $maskData[$key] ?? [];
                                    $enabled = ($config['enabled'] ?? true) !== false;
                                    $isFirst = $loop->first;
                                @endphp
                                <button type="button" onclick="customizer.switchCanvas('{{ $key }}')"
                                    class="cust-mobile-page-btn thumb-nav-btn {{ $isFirst ? 'active' : '' }} {{ !$enabled ? 'disabled-tab' : '' }}"
                                    data-key="{{ $key }}" data-short="P{{ $loop->iteration }}" data-full="Page {{ $loop->iteration }}">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/></svg>
                                    <span>{{ $isFirst ? 'Page '.$loop->iteration : 'P'.$loop->iteration }}</span>
                                    @if (!$enabled)
                                        <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="position:absolute;top:-2px;right:-2px;color:#ef4444;"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                                    @endif
                                </button>
                            @endforeach
                        </div>
                        @endif

                        <div class="w-full flex items-center justify-center py-2 relative" id="canvas-stage">

                            {{-- Non-Destructive Image Crop Banner --}}
                            <div id="crop-mode-banner"
                                class="hidden absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 bg-slate-900/95 backdrop-blur-md text-white px-5 py-2.5 rounded-full shadow-2xl border border-slate-700/80 animate-fade-in">
                                <div class="flex items-center gap-2">
                                    <div
                                        class="w-6 h-6 rounded-full bg-pink-500/20 text-pink-400 flex items-center justify-center">
                                        <i data-lucide="crop" class="w-3.5 h-3.5"></i>
                                    </div>
                                    <span class="text-xs font-bold text-slate-200">Image Crop Mode</span>
                                </div>
                                <div class="w-px h-4 bg-slate-700"></div>

                                {{-- Aspect Ratio Selector --}}
                                <div class="flex items-center gap-1.5">
                                    <span class="text-[10px] font-bold text-slate-400">Ratio:</span>
                                    <select onchange="customizer.setCropAspectRatio(this.value)"
                                        class="bg-slate-800 text-white text-xs font-bold px-2.5 py-1 rounded-lg outline-none cursor-pointer border border-slate-700">
                                        <option value="free">Free</option>
                                        <option value="1:1">1:1 Square</option>
                                        <option value="4:3">4:3 Standard</option>
                                        <option value="16:9">16:9 Widescreen</option>
                                        <option value="original">Original</option>
                                    </select>
                                </div>

                                <div class="w-px h-4 bg-slate-700"></div>

                                {{-- Reset Crop --}}
                                <button type="button" onclick="customizer.resetCrop()"
                                    class="px-2.5 py-1 text-slate-300 hover:text-white text-xs font-bold hover:bg-slate-800 rounded-lg transition-all">
                                    Reset
                                </button>

                                {{-- Cancel --}}
                                <button type="button" onclick="customizer.cancelCrop()"
                                    class="px-2.5 py-1 text-red-400 hover:text-red-300 text-xs font-bold hover:bg-slate-800 rounded-lg transition-all flex items-center gap-1">
                                    <i data-lucide="x" class="w-3.5 h-3.5"></i> Cancel
                                </button>

                                {{-- Apply --}}
                                <button type="button" onclick="customizer.applyCrop()"
                                    class="bg-brand-500 hover:bg-brand-600 text-slate-950 font-black text-xs px-3.5 py-1.5 rounded-full flex items-center gap-1.5 transition-all shadow-md cursor-pointer">
                                    <i data-lucide="check" class="w-3.5 h-3.5"></i> Apply Crop
                                </button>
                            </div>

                            {{-- Image Reposition Mode Banner --}}
                            <div id="reposition-mode-banner"
                                class="hidden absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 bg-purple-950/95 backdrop-blur-md text-white px-5 py-2.5 rounded-full shadow-2xl border border-purple-700/80 animate-fade-in">
                                <div class="flex items-center gap-2">
                                    <div
                                        class="w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center">
                                        <i data-lucide="move" class="w-3.5 h-3.5"></i>
                                    </div>
                                    <span class="text-xs font-bold text-purple-100">Reposition Image Inside Shape
                                        Mode</span>
                                </div>
                                <div class="w-px h-4 bg-purple-700"></div>
                                <button type="button" onclick="customizer.exitImageRepositionMode()"
                                    class="bg-purple-500 hover:bg-purple-600 text-white font-black text-xs px-4 py-1.5 rounded-full flex items-center gap-1.5 transition-all shadow-md cursor-pointer">
                                    <i data-lucide="check" class="w-3.5 h-3.5"></i> Finish Reposition
                                </button>
                            </div>

                            {{-- Group Edit Mode Banner --}}
                            <div id="group-edit-banner"
                                class="hidden absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 bg-indigo-950/95 backdrop-blur-md text-white px-5 py-2.5 rounded-full shadow-2xl border border-indigo-700/80 animate-fade-in">
                                <div class="flex items-center gap-2">
                                    <div
                                        class="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                                        <i data-lucide="folder-open" class="w-3.5 h-3.5"></i>
                                    </div>
                                    <span class="text-xs font-bold text-indigo-100">Editing objects inside Group...</span>
                                </div>
                                <div class="w-px h-4 bg-indigo-700"></div>
                                <button type="button" onclick="customizer.exitGroupEditMode()"
                                    class="bg-indigo-500 hover:bg-indigo-600 text-white font-black text-xs px-3.5 py-1.5 rounded-full flex items-center gap-1.5 transition-all shadow-md cursor-pointer">
                                    <i data-lucide="check" class="w-3.5 h-3.5"></i> Done Editing
                                </button>
                            </div>

                            {{-- Locked Canvas Banner --}}
                            <div id="canvas-locked-banner"
                                class="hidden absolute top-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-slate-800/90 backdrop-blur-sm text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-lg border border-slate-700/50">
                                <i data-lucide="lock" class="w-3.5 h-3.5 text-amber-400"></i>
                                <span>Disabled for edit</span>
                            </div>

                            {{-- Canvas Wrapper --}}
                            <div class="canvas-wrapper bg-white shadow-2xl rounded-2xl overflow-hidden relative mx-auto flex items-center justify-center transition-all duration-200"
                                id="canvas-container">
                                <div id="canvas-loading-overlay"
                                    class="hidden absolute inset-0 bg-white/80 backdrop-blur-xs z-50 flex flex-col items-center justify-center space-y-3 rounded-2xl transition-all duration-300">
                                    <div
                                        class="w-12 h-12 rounded-2xl bg-brand-50 border border-brand-100 flex items-center justify-center shadow-lg shadow-brand-500/10">
                                        <i data-lucide="loader-2" class="w-6 h-6 text-brand-600 animate-spin"></i>
                                    </div>
                                    <span class="text-xs font-black text-slate-800 tracking-wider uppercase">Loading
                                        Template...</span>
                                </div>

                                @foreach ($imageTypes as $key => $img)
                                    @php
                                        $config = $maskData[$key] ?? [];
                                        $enabled = ($config['enabled'] ?? true) !== false;
                                        $isFirst = $loop->first;
                                    @endphp
                                    <div id="canvas-wrapper-{{ $key }}"
                                        class="canvas-layer {{ !$isFirst ? 'canvas-hidden' : '' }}"
                                        style="position:absolute;top:0;left:0;width:100%;height:100%;display:{{ $isFirst ? 'block' : 'none' }};visibility:{{ $isFirst ? 'visible' : 'hidden' }};pointer-events:{{ $isFirst ? 'auto' : 'none' }};z-index:{{ $isFirst ? '10' : '-1' }};">
                                        <canvas id="canvas-{{ $key }}"></canvas>
                                        @if (!$enabled)
                                            <div class="canvas-disabled-overlay"></div>
                                        @endif
                                    </div>
                                @endforeach
                            </div>
                        </div>

                        {{-- Hidden JS Utility Elements --}}
                        <div style="display: none !important;">
                            <div id="zoom-control">
                                <input type="range" id="zoom-slider" min="0.1" max="3" step="0.01"
                                    value="1" oninput="customizer.updateImageScale(this.value)">
                            </div>
                        </div>
                    </div>

                    {{-- ═══ RIGHT: ABSOLUTE FLOATING VERTICAL STUDIO DOCK ═══ --}}
                    @include('quick-flow-pc.partials.customizer-right-dock', ['multiUpload' => false])

                </div>
            </div>
        </section>

    </div>
@endsection

@push('body_end')
<div id="mobile-customize-toolbar" style="display:none; position:fixed; bottom:0; left:0; right:0; z-index:9999; background:#ffffff; border-top:1px solid #e2e8f0; padding:12px 10px calc(22px + env(safe-area-inset-bottom, 22px)) 10px; box-shadow:0 -4px 16px rgba(0,0,0,0.12);">
    <div style="display:flex; align-items:center; justify-content:space-evenly; max-width:400px; margin:0 auto;">
        <label for="photo-upload-input" style="display:flex; flex-direction:column; align-items:center; gap:1px; cursor:pointer;">
            <div style="width:40px; height:40px; border-radius:14px; background:#fff0f6; border:1.5px solid #fbcfe8; display:flex; align-items:center; justify-content:center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ec4899" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
            </div>
            <span style="font-size:9px; font-weight:700; color:#ec4899;">Photo</span>
        </label>
        <button type="button" onclick="toggleTextDrawer()" style="display:flex; flex-direction:column; align-items:center; gap:1px; cursor:pointer; background:none; border:none; padding:0;">
            <div style="width:40px; height:40px; border-radius:14px; background:#faf5ff; border:1.5px solid #e9d5ff; display:flex; align-items:center; justify-content:center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#9333ea" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" x2="15" y1="20" y2="20"/><line x1="12" x2="12" y1="4" y2="20"/></svg>
            </div>
            <span style="font-size:9px; font-weight:700; color:#9333ea;">Text</span>
        </button>
        <button type="button" onclick="toggleShapesDrawer()" style="display:flex; flex-direction:column; align-items:center; gap:1px; cursor:pointer; background:none; border:none; padding:0;">
            <div style="width:40px; height:40px; border-radius:14px; background:#f0fdf4; border:1.5px solid #bbf7d0; display:flex; align-items:center; justify-content:center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.3 10a.7.7 0 0 1-.626-1.079L11.4 3a.7.7 0 0 1 1.198-.043L16.3 8.9a.7.7 0 0 1-.572 1.1Z"/><rect x="3" y="14" width="7" height="7" rx="1"/><circle cx="17.5" cy="17.5" r="3.5"/></svg>
            </div>
            <span style="font-size:9px; font-weight:700; color:#16a34a;">Shapes</span>
        </button>
        <button type="button" onclick="toggleTemplatesDrawer()" style="display:flex; flex-direction:column; align-items:center; gap:1px; cursor:pointer; background:none; border:none; padding:0;">
            <div style="width:40px; height:40px; border-radius:14px; background:#f8fafc; border:1.5px solid #e2e8f0; display:flex; align-items:center; justify-content:center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#475569" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="7" x="3" y="3" rx="1"/><rect width="9" height="7" x="3" y="14" rx="1"/><rect width="5" height="7" x="16" y="14" rx="1"/></svg>
            </div>
            <span style="font-size:9px; font-weight:700; color:#475569;">Design</span>
        </button>
        <button type="button" onclick="toggleLayersDrawer()" style="display:flex; flex-direction:column; align-items:center; gap:1px; cursor:pointer; background:none; border:none; padding:0;">
            <div style="width:40px; height:40px; border-radius:14px; background:#f8fafc; border:1.5px solid #e2e8f0; display:flex; align-items:center; justify-content:center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#475569" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/></svg>
            </div>
            <span style="font-size:9px; font-weight:700; color:#475569;">Layers</span>
        </button>
        <button type="button" onclick="customizer.submitAllCanvases()" style="display:flex; flex-direction:column; align-items:center; gap:1px; cursor:pointer; background:none; border:none; padding:0;">
            <div style="width:42px; height:42px; border-radius:14px; background:#287d3c; display:flex; align-items:center; justify-content:center; box-shadow:0 2px 8px rgba(40,125,60,0.3);">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
            </div>
            <span style="font-size:9px; font-weight:900; color:#287d3c;">Done</span>
        </button>
    </div>
</div>
<script>
(function(){
    var tb = document.getElementById('mobile-customize-toolbar');
    function toggle(){ if(tb) tb.style.display = window.innerWidth < 768 ? 'block' : 'none'; }
    toggle();
    window.addEventListener('resize', toggle);
})();
</script>
@endpush

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.1/fabric.min.js"></script>
    <script src="{{ asset('js/customizer-base.js') }}?v={{ time() }}"></script>
    <script>
        const customizer = Object.assign(customizerBase({
            storagePrefix: 'qrinto_design_v1',
            multiCanvas: true,
            hasMasks: {{ $lpo ? 'false' : 'true' }},
            imageTypes: @json($imageTypes),
            allMaskData: @json($maskData),
            productId: {{ $product->id }},
            templates: @json($activeTemplates ?? ($product->templates ?? [])),
            templateCategories: @json($templateCategories ?? []),
            csrfToken: '{{ csrf_token() }}',
            uploadRoute: '{{ route('flow.upload') }}',
            uploadCompositeRoute: '{{ route('flow.upload_composite') }}',
            isPortrait: {{ $lpo ? ($lpo['isPortrait'] ? 'true' : 'false') : (($product->pdf_orientation ?? 'portrait') === 'portrait' ? 'true' : 'false') }}
        }), {
            init() {
                if (typeof this.allMaskData === 'string') {
                    try {
                        this.allMaskData = JSON.parse(this.allMaskData);
                    } catch (e) {
                        this.allMaskData = {};
                    }
                }
                Object.keys(this.imageTypes).forEach(key => {
                    const config = this.allMaskData[key];
                    this.canvasEnabled[key] = (config && config.enabled === false) ? false : true;
                    this.canvasImages[key] = null;
                    this.uploadIds[key] = null;
                    this.imgScales[key] = 1;
                });
                const firstEnabled = Object.keys(this.canvasEnabled).find(k => this.canvasEnabled[k] === true);
                this.activeCanvas = firstEnabled || Object.keys(this.imageTypes)[0];

                const waitForLayout = () => {
                    // Gate on the stage width, NOT the canvas-container: the container's
                    // canvas layers are all position:absolute, so it collapses to 0px until
                    // _initAllCanvases() sizes it. Waiting on it would deadlock (canvas only
                    // appeared after a manual resize fired _resizeAllCanvases).
                    const stage = document.getElementById('canvas-stage');
                    const cont = document.getElementById('canvas-container');
                    if (stage && cont && stage.offsetWidth > 200) {
                        this._initAllCanvases();
                        this.updateUI();
                        this._initTemplates();
                    } else {
                        setTimeout(waitForLayout, 50);
                    }
                };
                setTimeout(waitForLayout, 50);
                window.addEventListener('resize', this._debounce(() => this._resizeAllCanvases(), 150));

                window.addEventListener('keydown', (e) => {
                    if ((e.key === 'Delete' || e.key === 'Backspace') && !['INPUT', 'TEXTAREA'].includes(
                            document.activeElement.tagName)) {
                        if (this.selectedObject) {
                            e.preventDefault();
                            this.handleRemove();
                        }
                    }
                });

                this.updateUI();
            },

            updateUI() {
                const key = this.activeCanvas;
                const enabled = this.canvasEnabled[key] !== false;
                const cv = this.canvases[key];
                const userImagesCount = cv ? cv.fabricCanvas.getObjects().filter(o => o._isUserImage).length : 0;
                const hasImg = userImagesCount > 0 || (this.canvasImages[key] !== null);

                // Canvas disabled overlay sync
                Object.keys(this.imageTypes).forEach(k => {
                    const wrapper = document.getElementById('canvas-wrapper-' + k);
                    if (!wrapper) return;
                    let overlay = wrapper.querySelector('.canvas-disabled-overlay');
                    if (this.canvasEnabled[k] === false) {
                        if (!overlay) {
                            overlay = document.createElement('div');
                            overlay.className = 'canvas-disabled-overlay';
                            wrapper.appendChild(overlay);
                        }
                    } else if (overlay) {
                        overlay.remove();
                    }
                });

                // Dock tools & panel triggers visibility based on lock state
                ['upload-tool-label', 'text-dock-trigger', 'shapes-dock-trigger', 'color-tool',
                    'fonts-dock-trigger', 'qr-dock-trigger', 'templates-dock-trigger', 'layers-dock-trigger',
                    'left-dock-divider'
                ].forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.style.display = enabled ? '' : 'none';
                });

                // Locked canvas banner
                const lockedBanner = document.getElementById('canvas-locked-banner');
                if (lockedBanner) lockedBanner.classList.toggle('hidden', enabled);

                // Reposition image buttons visibility
                const activeObj = cv?.fabricCanvas?.getActiveObject() || this.selectedObject;
                const hasShapeImage = !!(activeObj && (activeObj._filledImage || activeObj._parentShape || activeObj
                    .clipPath || activeObj._shapeMaskType));
                const repoTopBtn = document.getElementById('reposition-top-btn');
                const repoDrawerWrap = document.getElementById('reposition-shape-btn-wrap');
                if (repoTopBtn) repoTopBtn.classList.toggle('hidden', !hasShapeImage || this.isRepositioningImage);
                if (repoDrawerWrap) repoDrawerWrap.classList.toggle('hidden', !hasShapeImage || this
                    .isRepositioningImage);

                // Shape border controls UI sync
                const borderTarget = activeObj ? (activeObj._filledImage ? activeObj : (activeObj._parentShape ||
                    activeObj)) : null;
                if (borderTarget && (borderTarget.clipPath || borderTarget._shapeMaskType || borderTarget
                        ._filledImage || borderTarget._isShape)) {
                    const isShow = borderTarget._shapeBorderShow !== false && (borderTarget._shapeBorderShow || (
                        borderTarget._shapeBorderWidth && borderTarget._shapeBorderWidth > 0));
                    const borderCol = borderTarget._shapeBorderColor || (borderTarget.stroke && borderTarget
                        .stroke !== 'transparent' ? borderTarget.stroke : '#378ADD');
                    const borderW = borderTarget._shapeBorderWidth !== undefined ? borderTarget._shapeBorderWidth :
                        (borderTarget.strokeWidth || 3);
                    const borderSt = borderTarget._shapeBorderStyle || 'solid';

                    const borderShowCb = document.getElementById('shape-border-show-checkbox');
                    const borderColorInput = document.getElementById('shape-border-color-input');
                    const borderColorVal = document.getElementById('shape-border-color-val');
                    const borderWidthSlider = document.getElementById('shape-border-width-slider');
                    const borderWidthVal = document.getElementById('shape-border-width-val');
                    const borderStyleSelect = document.getElementById('shape-border-style-select');

                    if (borderShowCb) borderShowCb.checked = !!isShow;
                    if (borderColorInput) borderColorInput.value = borderCol;
                    if (borderColorVal) borderColorVal.innerText = borderCol;
                    if (borderWidthSlider) borderWidthSlider.value = borderW;
                    if (borderWidthVal) borderWidthVal.innerText = borderW + 'px';
                    if (borderStyleSelect) borderStyleSelect.value = borderSt;
                }

                // Group / Ungroup buttons visibility sync
                const isMultiSelection = activeObj && activeObj.type === 'activeSelection';
                const isGroup = activeObj && activeObj.type === 'group';
                const groupTopBtn = document.getElementById('group-top-btn');
                const ungroupTopBtn = document.getElementById('ungroup-top-btn');
                if (groupTopBtn) groupTopBtn.classList.toggle('hidden', !isMultiSelection);
                if (ungroupTopBtn) ungroupTopBtn.classList.toggle('hidden', !isGroup);

                // Crop & Mask buttons visibility sync (ONLY for image objects)
                const isImage = !!(activeObj && (activeObj._isUserImage || activeObj._isTemplateImage || activeObj
                    .type === 'image'));
                const cropTopBtn = document.getElementById('crop-top-btn');
                const maskTopBtn = document.getElementById('mask-top-btn');
                if (cropTopBtn) cropTopBtn.classList.toggle('hidden', !isImage || this.isCroppingImage);
                if (maskTopBtn) maskTopBtn.classList.toggle('hidden', !isImage);

                // Close drawers when switching to a locked canvas
                if (!enabled && typeof closeAllDrawers === 'function') {
                    closeAllDrawers();
                }

                // Left Dock Page Buttons Active & Lock State Sync
                Object.keys(this.imageTypes).forEach((k) => {
                    const btnIcon = document.getElementById('page-btn-' + k);
                    const btnWrapper = document.querySelector('.thumb-nav-btn[data-key="' + k + '"]');
                    const isEnabled = this.canvasEnabled[k] !== false;

                    if (btnIcon) {
                        let lockBadge = btnIcon.querySelector('.thumb-lock-badge');
                        if (!isEnabled) {
                            if (!lockBadge) {
                                lockBadge = document.createElement('div');
                                lockBadge.className =
                                    'thumb-lock-badge absolute -top-1 -right-1 w-5 h-5 rounded-full bg-slate-700 text-white flex items-center justify-center border-2 border-white shadow-sm z-20';
                                lockBadge.innerHTML = '<i data-lucide="lock" class="w-2.5 h-2.5"></i>';
                                btnIcon.appendChild(lockBadge);
                            }
                        } else if (lockBadge) {
                            lockBadge.remove();
                        }

                        if (k === key) {
                            btnIcon.className =
                                'w-12 h-12 rounded-2xl bg-white text-brand-600 shadow-md border-2 border-brand-500 flex items-center justify-center scale-105 transition-all duration-200 relative ' +
                                (!isEnabled ? 'opacity-70' : '');
                            if (btnWrapper) {
                                const txt = btnWrapper.querySelector('span');
                                if (txt) txt.className = 'text-[10px] font-black text-brand-600';
                            }
                        } else {
                            btnIcon.className =
                                'w-12 h-12 rounded-2xl bg-white text-slate-500 shadow-2xs border border-slate-200/90 flex items-center justify-center group-hover:text-brand-600 group-hover:border-brand-300 group-hover:scale-105 transition-all duration-200 relative ' +
                                (!isEnabled ? 'opacity-60' : '');
                            if (btnWrapper) {
                                const txt = btnWrapper.querySelector('span');
                                if (txt) txt.className =
                                    'text-[10px] font-bold text-slate-500 group-hover:text-brand-600 transition-colors';
                            }
                        }
                    }
                });

                // Mobile page switcher active state + label
                document.querySelectorAll('.cust-mobile-page-btn').forEach(function(btn) {
                    var span = btn.querySelector('span');
                    if (btn.getAttribute('data-key') === key) {
                        btn.classList.add('active');
                        if (span) span.textContent = btn.getAttribute('data-full');
                    } else {
                        btn.classList.remove('active');
                        if (span) span.textContent = btn.getAttribute('data-short');
                    }
                });

                // Canvas Visibility
                Object.keys(this.imageTypes).forEach(k => {
                    const el = document.getElementById('canvas-wrapper-' + k);
                    if (el) {
                        if (k === key) {
                            el.style.position = 'relative';
                            el.style.visibility = 'visible';
                            el.style.pointerEvents = 'auto';
                            el.style.zIndex = '1';
                        } else {
                            el.style.position = 'absolute';
                            el.style.visibility = 'hidden';
                            el.style.pointerEvents = 'none';
                            el.style.zIndex = '-1';
                        }
                    }
                });

                // Upload icon badge & text
                const uploadIconBg = document.getElementById('upload-icon-bg');
                const uploadText = document.getElementById('upload-text');
                if (hasImg) {
                    if (uploadIconBg) uploadIconBg.className =
                        'w-12 h-12 rounded-full  bg-gray-500 text-white shadow-xl flex items-center justify-center border  border-gray-400';
                    if (uploadText) uploadText.textContent = userImagesCount > 1 ? 'Photo (' + userImagesCount +
                        ')' : 'Photo';
                } else {
                    if (uploadIconBg) uploadIconBg.className =
                        'w-12 h-12 rounded-full bg-white text-brand-500 shadow-xl flex items-center justify-center border border-slate-200';
                    if (uploadText) uploadText.textContent = 'Photo';
                }

                // Zoom
                document.getElementById('zoom-control')?.classList.toggle('hidden', !hasImg);

                // Selection sync
                this._syncToolbarToSelection(this.selectedObject);

                // Remove button
                const showRemove = enabled && (hasImg || !!this.selectedObject);
                const removeBtn = document.getElementById('remove-btn');
                if (removeBtn) removeBtn.classList.toggle('hidden', !showRemove);
                const removeBtnText = document.getElementById('remove-btn-text');
                if (showRemove && removeBtnText) {
                    if (this.selectedObject && (this.selectedObject._isUserText || this.selectedObject
                            ._isTemplateText)) {
                        removeBtnText.textContent = 'Remove Text';
                    } else if (this.selectedObject && (this.selectedObject._isUserImage || this.selectedObject
                            ._isTemplateImage)) {
                        removeBtnText.textContent = 'Remove Image';
                    } else {
                        removeBtnText.textContent = 'Remove';
                    }
                }

                this.renderLayersPanel();
                if (window.lucide) window.lucide.createIcons();
            },

            _calcCanvasDimensions(stageEl, customConfig) {
                const stageH = (stageEl && stageEl.offsetHeight > 200) ? stageEl.offsetHeight : Math.round(window
                    .innerHeight * 0.8);
                const dockOffset = window.innerWidth < 768 ? 16 : 180;
                const stageW = (stageEl && stageEl.offsetWidth > 200) ? stageEl.offsetWidth - dockOffset : 900;

                const isPortrait = this._config.isPortrait;
                const adminW = (customConfig && customConfig.canvasWidth) || (isPortrait ? 400 : 560);
                const adminH = (customConfig && customConfig.canvasHeight) || (isPortrait ? 560 : 400);

                let targetH = Math.round(stageH * 0.8);
                let scaleFactor = targetH / adminH;
                let targetW = Math.round(adminW * scaleFactor);

                if (targetW > stageW) {
                    targetW = stageW;
                    scaleFactor = targetW / adminW;
                    targetH = Math.round(adminH * scaleFactor);
                }

                return {
                    displayWidth: targetW,
                    displayHeight: targetH,
                    scaleFactor,
                    adminW,
                    adminH
                };
            },

            _initAllCanvases() {
                const containerEl = document.getElementById('canvas-container');
                const stageEl = document.getElementById('canvas-stage');
                if (!containerEl) return;

                const sharedConfig = Object.keys(this.imageTypes)
                    .map(k => this.allMaskData[k] || {})
                    .find(c => c.canvasWidth && c.canvasHeight) || {};

                const {
                    displayWidth,
                    displayHeight,
                    scaleFactor,
                    adminW,
                    adminH
                } = this._calcCanvasDimensions(stageEl, sharedConfig);

                containerEl.style.height = displayHeight + 'px';
                containerEl.style.width = displayWidth + 'px';
                containerEl.style.maxWidth = '100%';

                Object.keys(this.imageTypes).forEach(key => {
                    const canvasEl = document.getElementById('canvas-' + key);
                    if (!canvasEl) return;

                    const fc = new fabric.Canvas('canvas-' + key, {
                        width: displayWidth,
                        height: displayHeight,
                        backgroundColor: '#ffffff',
                        selection: true,
                        preserveObjectStacking: false,
                        allowTouchScrolling: true
                    });

                    this.canvases[key] = {
                        fabricCanvas: fc,
                        imgObj: null,
                        scaleFactor: scaleFactor,
                        adminW: adminW,
                        adminH: adminH
                    };

                    const url = this.imageTypes[key]?.url;
                    if (url) {
                        const bgCors = (!url || url.startsWith('data:') || url.startsWith('blob:')) ? {} : {
                            crossOrigin: 'anonymous'
                        };
                        fabric.Image.fromURL(url, img => {
                            img.set({
                                left: -1,
                                top: -1,
                                scaleX: (displayWidth + 2) / img.width,
                                scaleY: (displayHeight + 2) / img.height,
                                selectable: false,
                                evented: false
                            });
                            fc.setBackgroundImage(img, fc.requestRenderAll.bind(fc));
                        }, bgCors);
                    }

                    // Add mask guides if applicable
                    const firstKey = Object.keys(this.imageTypes)[0];
                    const mData = this.allMaskData[key] || {};
                    const masks = mData.masks || this.allMaskData.masks;
                    if (key === firstKey && Array.isArray(masks) && masks.length > 0) {
                        this.canvases[key].maskGuides = [];
                        masks.forEach((m, idx) => {
                            const guide = this._createMaskObject(m, scaleFactor, {
                                fill: 'transparent',
                                stroke: 'rgba(0, 80, 220, 0.5)',
                                strokeWidth: 1,
                                selectable: false,
                                evented: false,
                                name: 'mask_guide_' + idx
                            });
                            if (guide) {
                                fc.add(guide);
                                this.canvases[key].maskGuides.push(guide);
                            }
                        });
                    }

                    if (this.canvasEnabled[key] === false) {
                        fc.selection = false;
                        fc.interactive = false;
                        fc.skipTargetFind = true;
                        fc.defaultCursor = 'not-allowed';
                        fc.hoverCursor = 'not-allowed';
                    }

                    fc.on('selection:created', (e) => {
                        if (this.canvasEnabled[key] === false) {
                            fc.discardActiveObject();
                            fc.renderAll();
                            return;
                        }
                        let sel = e.selected ? e.selected[0] : null;
                        if (!this.isRepositioningImage && sel && sel._parentShape) {
                            sel = sel._parentShape;
                            fc.setActiveObject(sel);
                        }
                        this.selectedObject = sel;
                        this.updateUI();
                    });
                    fc.on('selection:updated', (e) => {
                        if (this.canvasEnabled[key] === false) {
                            fc.discardActiveObject();
                            fc.renderAll();
                            return;
                        }
                        let sel = e.selected ? e.selected[0] : null;
                        if (!this.isRepositioningImage && sel && sel._parentShape) {
                            sel = sel._parentShape;
                            fc.setActiveObject(sel);
                        }
                        this.selectedObject = sel;
                        this.updateUI();
                    });
                    fc.on('selection:cleared', () => {
                        if (this.activeCanvas !== key) return;
                        this.selectedObject = null;
                        this.updateUI();
                    });
                    fc.on('object:modified', () => {
                        this._saveCanvasState(key);
                        this.pushHistoryState(key);
                    });
                    fc.on('object:added', () => this._saveCanvasState(key));
                    fc.on('object:removed', () => {
                        this._saveCanvasState(key);
                        this.pushHistoryState(key);
                    });
                    fc.on('object:moving', (e) => {
                        if (e.target && this._syncShapeAndImage) {
                            if (e.target._filledImage) {
                                this._syncShapeAndImage(e.target);
                            } else if (e.target._parentShape) {
                                this._syncShapeAndImage(e.target._parentShape);
                            } else if (e.target.clipPath || e.target._shapeMaskType) {
                                this._syncShapeAndImage(e.target);
                            }
                        }
                    });
                    fc.on('object:scaling', (e) => {
                        if (e.target._isUserImage) {
                            this.imgScales[key] = e.target.scaleX;
                            const s = document.getElementById('zoom-slider');
                            if (s) s.value = e.target.scaleX;
                        }
                        if (e.target && this._syncShapeAndImage) {
                            if (e.target._filledImage) {
                                this._syncShapeAndImage(e.target);
                            } else if (e.target._parentShape) {
                                this._syncShapeAndImage(e.target._parentShape);
                            } else if (e.target.clipPath || e.target._shapeMaskType) {
                                this._syncShapeAndImage(e.target);
                            }
                        }
                        this._saveCanvasState(key);
                    });
                    fc.on('object:rotating', (e) => {
                        if (e.target && this._syncShapeAndImage) {
                            if (e.target._filledImage) {
                                this._syncShapeAndImage(e.target);
                            } else if (e.target._parentShape) {
                                this._syncShapeAndImage(e.target._parentShape);
                            } else if (e.target.clipPath || e.target._shapeMaskType) {
                                this._syncShapeAndImage(e.target);
                            }
                        }
                    });

                    this._loadCanvasState(key);
                    fc.renderAll();

                    // Push initial state so undo has a base to return to
                    setTimeout(() => this.pushHistoryState(key), 300);
                });

                const firstKey = Object.keys(this.imageTypes)[0];
                if (firstKey) this.switchCanvas(firstKey);
            },

            _resizeAllCanvases() {
                const containerEl = document.getElementById('canvas-container');
                const stageEl = document.getElementById('canvas-stage');
                if (!containerEl || !stageEl) return;

                const sharedConfig = Object.keys(this.imageTypes)
                    .map(k => this.allMaskData[k] || {})
                    .find(c => c.canvasWidth && c.canvasHeight) || {};

                const {
                    displayWidth,
                    displayHeight,
                    scaleFactor: newSf
                } = this._calcCanvasDimensions(stageEl, sharedConfig);

                containerEl.style.width = displayWidth + 'px';
                containerEl.style.height = displayHeight + 'px';

                Object.keys(this.canvases).forEach(key => {
                    const cv = this.canvases[key];
                    if (!cv || !cv.fabricCanvas) return;

                    const newW = displayWidth;
                    const targetH = displayHeight;
                    const ratio = newW / (cv.fabricCanvas.width || newW);

                    cv.fabricCanvas.setWidth(newW);
                    cv.fabricCanvas.setHeight(targetH);

                    const bg = cv.fabricCanvas.backgroundImage;
                    if (bg) {
                        bg.left = -1;
                        bg.top = -1;
                        bg.scaleX = (newW + 2) / bg.width;
                        bg.scaleY = (targetH + 2) / bg.height;
                    }

                    cv.fabricCanvas.getObjects().forEach(o => {
                        o.left *= ratio;
                        o.top *= ratio;
                        o.scaleX *= ratio;
                        o.scaleY *= ratio;
                        if (o.clipPath) {
                            const newClip = this._createCombinedClipPath(key, newSf);
                            if (newClip) {
                                newClip.canvas = cv.fabricCanvas;
                                o.set('clipPath', newClip);
                            }
                        }
                        o.setCoords();
                    });

                    if (cv.maskGuides && cv.maskGuides.length > 0) {
                        cv.maskGuides.forEach(g => cv.fabricCanvas.remove(g));
                        cv.maskGuides = [];
                        const mData = this.allMaskData[key] || {};
                        const masks = mData.masks || this.allMaskData.masks;
                        if (Array.isArray(masks)) {
                            masks.forEach((m, idx) => {
                                const guide = this._createMaskObject(m, newSf, {
                                    fill: 'transparent',
                                    stroke: 'rgba(0, 80, 220, 0.5)',
                                    strokeWidth: 1,
                                    selectable: false,
                                    evented: false,
                                    name: 'mask_guide_' + idx
                                });
                                if (guide) {
                                    cv.fabricCanvas.add(guide);
                                    cv.maskGuides.push(guide);
                                    guide.bringToFront();
                                }
                            });
                        }
                    }
                    cv.scaleFactor = newSf;
                    cv.fabricCanvas.renderAll();
                });
            }
        });

        document.addEventListener('DOMContentLoaded', () => {
            customizer.init();
            if (customizer.initKeyboardShortcuts) customizer.initKeyboardShortcuts();

            const stage = document.getElementById('canvas-stage');
            if (stage) {
                stage.addEventListener('dragover', (e) => {
                    e.preventDefault();
                    e.dataTransfer.dropEffect = 'copy';
                    stage.classList.add('ring-4', 'ring-brand-500/50', 'rounded-2xl');
                });
                stage.addEventListener('dragleave', (e) => {
                    e.preventDefault();
                    stage.classList.remove('ring-4', 'ring-brand-500/50', 'rounded-2xl');
                });
                stage.addEventListener('drop', (e) => {
                    e.preventDefault();
                    stage.classList.remove('ring-4', 'ring-brand-500/50', 'rounded-2xl');
                    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                        customizer.handleFileDrop(e);
                    }
                });

                stage.addEventListener('contextmenu', (e) => {
                    e.preventDefault();
                    const menu = document.getElementById('customizer-context-menu');
                    if (menu) {
                        menu.style.left = Math.min(e.clientX, window.innerWidth - 220) + 'px';
                        menu.style.top = Math.min(e.clientY, window.innerHeight - 260) + 'px';
                        menu.classList.remove('hidden');
                        if (window.lucide) window.lucide.createIcons();
                    }
                });
            }

            // ── Custom styled tooltips for the top toolbar ──
            (function initToolbarTooltips() {
                const bar = document.querySelector('#customizer-app .max-w-6xl');
                if (!bar) return;
                let pop = document.getElementById('tt-pop');
                if (!pop) {
                    pop = document.createElement('div');
                    pop.id = 'tt-pop';
                    document.body.appendChild(pop);
                }
                const show = (el) => {
                    let tip = el.getAttribute('data-tip') || el.getAttribute('title');
                    if (!tip) return;
                    // Move title → data-tip once, so the native tooltip doesn't double up.
                    if (el.hasAttribute('title')) {
                        el.setAttribute('data-tip', tip);
                        el.removeAttribute('title');
                    }
                    pop.textContent = tip;
                    const r = el.getBoundingClientRect();
                    let x = r.left + r.width / 2;
                    x = Math.max(48, Math.min(x, window.innerWidth - 48));
                    pop.style.left = x + 'px';
                    pop.style.top = (r.bottom + 10) + 'px';
                    pop.classList.add('show');
                };
                const hide = () => pop.classList.remove('show');
                bar.querySelectorAll('button, select, #preflight-badge').forEach((el) => {
                    el.addEventListener('mouseenter', () => show(el));
                    el.addEventListener('mouseleave', hide);
                    el.addEventListener('click', hide);
                    el.addEventListener('blur', hide);
                });
            })();
        });
    </script>
@endpush
