@extends('layouts.quick-flow-pc')
@section('title', 'Check & print | Qrinto')

@section('content')
    <div class="w-full bg-[#fafcf9] min-h-screen py-4 px-3 md:py-10 md:px-6 lg:px-16 font-sans">
        <div class="max-w-[1080px] mx-auto" x-data="checkFlow(
            {{ Illuminate\Support\Js::from(['url' => $file['url'], 'name' => $file['name'], 'bytes' => $file['bytes'], 'type' => $file['type']]) }},
            {{ Illuminate\Support\Js::from($trays) }},
            {{ Illuminate\Support\Js::from($trayDims) }}
        )" x-init="init()">

            <div class="flex items-center gap-2 mb-3 md:mb-4">
                <a href="{{ route('localprint.pdf') }}"
                    class="text-[11px] md:text-xs font-semibold text-slate-500 hover:text-emerald-700 transition-colors shrink-0">
                    ← <span class="hidden md:inline">Back</span>
                </a>
                <h1 class="text-base md:hidden font-extrabold text-[#112419] tracking-tight">Check & print</h1>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 items-start">

                {{-- Left: file + specs --}}
                <div class="bg-white border border-slate-200/80 rounded-xl md:rounded-2xl p-4 md:p-6">
                    <div class="flex items-start justify-between gap-3">
                        <div class="min-w-0">
                            <h2 class="font-bold text-slate-900 text-sm truncate" x-text="file.name" :title="file.name">
                            </h2>
                            <p class="mono text-[11px] text-slate-400 mt-0.5" x-text="prettySize(file.bytes)"></p>
                        </div>
                        <div x-show="file.type === 'pdf'" class="flex items-center gap-1.5 shrink-0">
                            <button type="button" @click="prevPage()" :disabled="page <= 1 || pages <= 1"
                                class="w-7 h-7 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition">
                                <i data-lucide="chevron-left" class="w-3.5 h-3.5"></i>
                            </button>
                            <span class="mono text-[11px] text-slate-500 tabular-nums w-14 text-center">
                                <span x-text="page"></span> / <span x-text="pages || '-'"></span>
                            </span>
                            <button type="button" @click="nextPage()" :disabled="page >= pages || pages <= 1"
                                class="w-7 h-7 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition">
                                <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                            </button>
                        </div>
                    </div>

                    <div class="bg-[#f2f7f2] rounded-xl mt-4 p-4 flex items-center justify-center relative"
                        :class="orientation === 'landscape' ? 'min-h-[100px] md:min-h-[200px]' : 'min-h-[140px] md:min-h-[280px]'">
                        <div x-show="!ready" x-cloak class="text-center">
                            <div
                                class="w-8 h-8 border-2 border-slate-300 border-t-[#287d3c] rounded-full animate-spin mx-auto">
                            </div>
                            <p class="mono text-[11px] text-slate-500 mt-3">Reading PDF…</p>
                        </div>
                        <div x-show="pdfError" x-cloak class="text-center">
                            <i data-lucide="file-warning" class="w-6 h-6 text-red-500 mx-auto"></i>
                            <p class="text-[12px] text-red-600 font-medium mt-2" x-text="pdfError"></p>
                        </div>
                        <canvas x-show="ready && !pdfError && file.type === 'pdf'" x-ref="pdfCanvas"
                            class="max-w-full rounded-sm shadow-lg bg-white"
                            :class="orientation === 'landscape' ? 'max-h-[130px] md:max-h-[260px]' : 'max-h-[210px] md:max-h-[420px]'"></canvas>
                        <img x-ref="imgPreview" x-show="ready && !pdfError && file.type === 'image'" :src="file.url"
                            class="max-w-full max-h-[160px] md:max-h-[320px] rounded-sm shadow-lg bg-white object-contain" />
                    </div>

                    <div class="mono text-[13px] text-slate-500 mt-5 space-y-1.5">
                        <p x-show="file.type === 'pdf'"><span class="text-slate-900 font-bold" x-text="pages || '-'"></span>
                            pages</p>
                        <p><span class="text-slate-900 font-bold">
                                <template x-if="dims"><span
                                        x-text="`${fmt(dims.w)} × ${fmt(dims.h)} in`"></span></template>
                                <template x-if="!dims"><span>-</span></template>
                            </span> <span x-text="orientation ? `(${orientation})` : ''"></span></p>
                        <p><span class="text-slate-900 font-bold" x-text="dpi ? `${dpi} dpi` : ''"></span> </p>
                        <p><span class="text-slate-900 font-bold" x-text="colorMode || '-'"></span> color</p>
                    </div>
                </div>

                {{-- Right: preflight + tray + print --}}
                <div class="bg-white border border-slate-200/80 rounded-xl md:rounded-2xl p-4 md:p-6">
                    <h2 class="font-bold text-slate-900 text-sm mb-4">Checks</h2>

                    {{-- Orientation check (only shown when there's a mismatch) --}}
                    <template x-if="orientationCheck && !orientationCheck.ok">
                        <div class="pb-4 border-b border-slate-100">
                            <div class="flex items-start gap-2.5">
                                <i data-lucide="alert-triangle" class="w-4 h-4 text-amber-500 mt-0.5 shrink-0"></i>
                                <div>
                                    <p class="text-[13px] font-bold text-slate-900">Orientation does not match</p>
                                    <p class="text-[12px] text-slate-500 mt-0.5" x-text="orientationCheck.detail"></p>
                                    <div class="flex gap-2 mt-2.5">
                                        <button type="button" @click="orientationAction = 'rotate'"
                                            class="mono text-[12px] px-3 py-1.5 rounded-lg border transition"
                                            :class="orientationAction === 'rotate' ?
                                                'border-[#287d3c] text-[#287d3c] bg-[#f2f7f2] font-bold' :
                                                'border-slate-200 text-slate-600 hover:border-slate-300'">Rotate
                                            the file</button>
                                        <button type="button" @click="orientationAction = 'asis'"
                                            class="mono text-[12px] px-3 py-1.5 rounded-lg border transition"
                                            :class="orientationAction === 'asis' ?
                                                'border-[#287d3c] text-[#287d3c] bg-[#f2f7f2] font-bold' :
                                                'border-slate-200 text-slate-600 hover:border-slate-300'">Print
                                            as is</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </template>

                    {{-- Dynamic check rows --}}
                    <div class="grid grid-cols-2 md:grid-cols-1 gap-x-4">
                    <template x-for="c in checks" :key="c.key">
                        <div class="flex items-start gap-2.5 py-3.5 border-b border-slate-100">
                            <template x-if="c.ok">
                                <i data-lucide="check" class="w-4 h-4 text-[#287d3c] mt-0.5 shrink-0"></i>
                            </template>
                            <template x-if="!c.ok && c.severity === 'warn'">
                                <i data-lucide="alert-triangle" class="w-4 h-4 text-amber-500 mt-0.5 shrink-0"></i>
                            </template>
                            <template x-if="!c.ok && c.severity === 'error'">
                                <i data-lucide="x" class="w-4 h-4 text-red-500 mt-0.5 shrink-0"></i>
                            </template>
                            <div>
                                <p class="text-[13px] font-bold text-slate-900" x-text="c.title"></p>
                                <p class="text-[12px] text-slate-500 mt-0.5" x-text="c.detail"></p>
                            </div>
                        </div>
                    </template>
                    </div>

                    <div class="mt-5">
                        @if ($storeName)
                            <p class="text-[12px] text-slate-500 mb-3">
                                <i data-lucide="store" class="w-3.5 h-3.5 inline -mt-0.5"></i>
                                Printing as <span class="font-bold text-slate-700">{{ $storeName }}</span>
                            </p>
                        @endif

                        {{-- PrintTrays bridge status --}}
                        <div class="flex items-center gap-2 mb-4 px-3 py-2 rounded-lg text-[12px]"
                            :class="bridgeReady ? 'bg-emerald-50 text-emerald-700' : (bridgeChecking ? 'bg-slate-50 text-slate-500' :
                                'bg-red-50 text-red-600')">
                            <template x-if="bridgeChecking">
                                <span>
                                    <div
                                        class="w-3.5 h-3.5 border-2 border-slate-300 border-t-slate-600 rounded-full animate-spin inline-block">
                                    </div>
                                    Connecting to PrintTrays…
                                </span>
                            </template>
                            <template x-if="!bridgeChecking && bridgeReady">
                                <span><i data-lucide="check-circle" class="w-3.5 h-3.5 inline -mt-0.5"></i> PrintTrays
                                    connected <span class="text-slate-400" x-show="bridgeVersion" x-text="'v' + bridgeVersion"></span></span>
                            </template>
                            <template x-if="!bridgeChecking && !bridgeReady">
                                <span class="flex items-center gap-1.5 w-full">
                                    <i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0"></i>
                                    <span class="flex-1">PrintTrays is not installed or not running</span>
                                    <button type="button" @click="showBridgeModal = true"
                                        class="font-bold underline hover:no-underline shrink-0">Fix this</button>
                                </span>
                            </template>
                        </div>

                        {{-- PrintTrays download modal --}}
                        <div x-show="showBridgeModal" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4"
                            @keydown.escape.window="showBridgeModal = false">
                            <div class="absolute inset-0 bg-black/40" @click="showBridgeModal = false"></div>
                            <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-md p-6" @click.stop>
                                <div class="flex items-center justify-between mb-4">
                                    <h3 class="font-bold text-slate-900 text-base">PrintTrays Required</h3>
                                    <button type="button" @click="showBridgeModal = false"
                                        class="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition">
                                        <i data-lucide="x" class="w-4 h-4"></i>
                                    </button>
                                </div>

                                <div class="text-center py-4">
                                    <div
                                        class="w-14 h-14 rounded-2xl bg-red-50 flex items-center justify-center mx-auto mb-4">
                                        <i data-lucide="printer" class="w-7 h-7 text-red-500"></i>
                                    </div>
                                    <p class="text-sm text-slate-700 font-medium">PrintTrays is required to connect to your
                                        local printer.</p>
                                    <p class="text-[12px] text-slate-500 mt-2 leading-relaxed">
                                        Download and install PrintTrays, then reload this page. It runs in the background and
                                        lets your browser communicate with printers on this PC.
                                    </p>
                                </div>

                                <div class="space-y-2 mt-4">
                                    <a href="https://noritsucanada.com/print-trays/download/" target="_blank"
                                        class="w-full flex items-center justify-center gap-2 bg-[#287d3c] hover:bg-emerald-800 text-white font-bold py-3 rounded-xl text-sm transition active:scale-[0.99]">
                                        <i data-lucide="download" class="w-4 h-4"></i> Download PrintTrays
                                    </a>
                                    <a href="https://www.dropbox.com/scl/fi/d5f74l6ekg7r3hoxhvhwm/Noritsu_931BL_Driver_Setup-v2.2.exe?rlkey=m94hgu9eww95zj7mr7wtpli30&st=e658g2hc&e=1&dl=1"
                                        target="_blank"
                                        class="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-900 text-white font-bold py-3 rounded-xl text-sm transition active:scale-[0.99]">
                                        <i data-lucide="download" class="w-4 h-4"></i>Download 931-BL Multi
                                        Driver
                                    </a>
                                    <button type="button" @click="showBridgeModal = false; bridgeChecking = true; initBridge();"
                                        class="w-full flex items-center justify-center gap-2 border border-slate-200 text-slate-600 font-semibold py-2.5 rounded-xl text-sm hover:bg-slate-50 transition">
                                        <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i> I've installed it - retry
                                        connection
                                    </button>
                                </div>
                            </div>
                        </div>

                        {{-- Printer list from PrintTrays --}}
                        <div x-show="bridgeReady">
                            <label class="text-sm font-semibold text-slate-700 mb-2 block">Select Printer</label>
                            <div class="space-y-2" x-show="printers.length > 0">
                                <template x-for="p in printers" :key="p.name">
                                    <label
                                        class="flex items-center gap-3 px-4 py-3 rounded-xl border cursor-pointer transition"
                                        :class="selectedPrinter === p.name ? 'border-[#287d3c] bg-[#f2f7f2]' :
                                            'border-slate-200 hover:border-slate-300'"
                                        @click="selectPrinter(p.name)">
                                        <input type="radio" name="printer_radio" :checked="selectedPrinter === p.name"
                                            :value="p.name" class="accent-[#287d3c] w-4 h-4">
                                        <div class="min-w-0 flex-1">
                                            <span class="font-bold text-[13px] text-slate-900" x-text="p.name"></span>
                                            <p class="text-[11px] text-slate-400 mt-0.5" x-show="p.driver" x-text="p.driver"></p>
                                            <template x-if="selectedPrinter === p.name">
                                                <p class="text-[11px] text-slate-500 mt-0.5"
                                                    x-text="printSettingsSummary"></p>
                                            </template>
                                        </div>
                                        <template x-if="selectedPrinter === p.name">
                                            <button type="button" @click.stop="showPaperModal = true"
                                                class="text-[11px] text-[#287d3c] font-bold hover:underline shrink-0">Settings</button>
                                        </template>
                                    </label>
                                </template>
                            </div>
                            <p x-show="printers.length === 0" class="text-[12px] text-slate-400">No printers found on this
                                PC.</p>
                        </div>

                        <div class="flex items-center justify-between mt-5">
                            <label class="text-sm font-semibold text-slate-700">Copies</label>
                            <div class="flex items-center gap-1.5">
                                <button type="button" @click="copies = Math.max(1, copies - 1)"
                                    class="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-50 active:scale-95 transition disabled:opacity-40"
                                    :disabled="copies <= 1">−</button>
                                <input type="number" name="copies" x-model.number="copies" min="1" max="999"
                                    class="w-16 text-center rounded-lg border border-slate-200 px-2 py-1.5 text-sm font-bold focus:ring-2 focus:ring-[#287d3c] focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none">
                                <button type="button" @click="copies = Math.min(999, copies + 1)"
                                    class="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-50 active:scale-95 transition disabled:opacity-40"
                                    :disabled="copies >= 999">+</button>
                            </div>
                        </div>

                        {{-- Print status toast --}}
                        <div x-show="printMsg" x-cloak x-transition
                            class="mt-3 px-3 py-2 rounded-lg text-[12px] font-medium"
                            :class="printMsgKind === 'success' ? 'bg-emerald-50 text-emerald-700' : (
                                printMsgKind === 'error' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'
                            )"
                            x-text="printMsg"></div>

                        <button type="button" @click="doPrint()" :disabled="!canPrint || printing"
                            class="w-full mt-4 bg-[#287d3c] hover:bg-emerald-800 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold py-3 rounded-xl text-sm transition active:scale-[0.99]">
                            <template x-if="printing"><span>Sending to printer…</span></template>
                            <template x-if="!printing && canPrint"><span>Print <span x-text="copies"></span> <span
                                        x-text="copies == 1 ? 'copy' : 'copies'"></span></span></template>
                            <template x-if="!printing && !canPrint"><span
                                    x-text="blocker || 'Not ready to print'"></span></template>
                        </button>

                        <p class="text-center mt-3">
                            <a href="https://noritsucanada.com/print-trays/download/" target="_blank"
                                class="text-[12px] text-slate-400 hover:text-[#287d3c] transition inline-flex items-center gap-1">
                                <i data-lucide="download" class="w-3.5 h-3.5"></i> Download PrintTrays
                            </a>
                        </p>
                    </div>

                </div>

            </div>

            {{-- Print settings modal --}}
            <div x-show="showPaperModal" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4"
                @keydown.escape.window="showPaperModal = false">
                <div class="absolute inset-0 bg-black/40" @click="showPaperModal = false"></div>
                <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto p-6" @click.stop>
                    <div class="flex items-center justify-between mb-5">
                        <h3 class="font-bold text-slate-900 text-base">Print Settings</h3>
                        <button type="button" @click="showPaperModal = false"
                            class="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition">
                            <i data-lucide="x" class="w-4 h-4"></i>
                        </button>
                    </div>

                    <div x-show="selectedPrinter" class="mb-4">
                        <p class="text-[12px] text-slate-500">
                            Configuring <span class="font-bold text-slate-700" x-text="selectedPrinter"></span>
                        </p>
                        <p class="text-[11px] text-slate-400 mt-0.5" x-show="selectedPrinterInfo?.driver"
                            x-text="'Driver: ' + selectedPrinterInfo?.driver"></p>
                        <p class="text-[11px] mt-0.5" x-show="selectedPrinterInfo?.status"
                            :class="selectedPrinterInfo?.status === 'idle' ? 'text-emerald-600' : 'text-amber-600'"
                            x-text="'Status: ' + selectedPrinterInfo?.status"></p>
                    </div>

                    <div class="grid grid-cols-2 gap-x-3 gap-y-4">
                        {{-- Paper Size --}}
                        <div>
                            <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Paper Size</label>
                            <select x-model="printPaperSize"
                                class="w-full rounded-xl border border-slate-200 text-sm py-2.5 px-3 bg-white focus:ring-2 focus:ring-[#287d3c] focus:outline-none">
                                @foreach ($sizeOptions as $val => $label)
                                    <option value="{{ $val }}">{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>

                        {{-- Orientation --}}
                        <div>
                            <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Orientation</label>
                            <div class="flex gap-1.5">
                                <button type="button" @click="printLandscape = false"
                                    class="flex-1 flex items-center justify-center gap-1 mono text-[11px] px-2 py-2.5 rounded-lg border transition"
                                    :class="!printLandscape ? 'border-[#287d3c] text-[#287d3c] bg-[#f2f7f2] font-bold' :
                                        'border-slate-200 text-slate-600 hover:border-slate-300'">
                                    <svg class="w-3.5 h-[18px] shrink-0" viewBox="0 0 16 20" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="1" width="12" height="18" rx="1.5"/></svg>
                                    Portrait
                                </button>
                                <button type="button" @click="printLandscape = true"
                                    class="flex-1 flex items-center justify-center gap-1 mono text-[11px] px-2 py-2.5 rounded-lg border transition"
                                    :class="printLandscape ? 'border-[#287d3c] text-[#287d3c] bg-[#f2f7f2] font-bold' :
                                        'border-slate-200 text-slate-600 hover:border-slate-300'">
                                    <svg class="w-[18px] h-3.5 shrink-0" viewBox="0 0 20 16" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="1" y="2" width="18" height="12" rx="1.5"/></svg>
                                    Landscape
                                </button>
                            </div>
                        </div>

                        {{-- Duplex --}}
                        <div>
                            <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Duplex</label>
                            <select x-model="printDuplex"
                                class="w-full rounded-xl border border-slate-200 text-sm py-2.5 px-3 bg-white focus:ring-2 focus:ring-[#287d3c] focus:outline-none">
                                <template x-for="d in duplexOptions" :key="d.value">
                                    <option :value="d.value" x-text="d.label"></option>
                                </template>
                            </select>
                        </div>

                        {{-- Margins --}}
                        <div>
                            <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Margins</label>
                            <select x-model="printMargins"
                                class="w-full rounded-xl border border-slate-200 text-sm py-2.5 px-3 bg-white focus:ring-2 focus:ring-[#287d3c] focus:outline-none">
                                <template x-for="m in marginOptions" :key="m.value">
                                    <option :value="m.value" x-text="m.label"></option>
                                </template>
                            </select>
                        </div>

                        {{-- Color Mode --}}
                        <div>
                            <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Color</label>
                            <div class="flex gap-1.5">
                                <button type="button" @click="printColor = true"
                                    class="flex-1 mono text-[11px] px-2 py-2.5 rounded-lg border transition text-center"
                                    :class="printColor ? 'border-[#287d3c] text-[#287d3c] bg-[#f2f7f2] font-bold' :
                                        'border-slate-200 text-slate-600 hover:border-slate-300'">Color</button>
                                <button type="button" @click="printColor = false"
                                    class="flex-1 mono text-[11px] px-2 py-2.5 rounded-lg border transition text-center"
                                    :class="!printColor ? 'border-[#287d3c] text-[#287d3c] bg-[#f2f7f2] font-bold' :
                                        'border-slate-200 text-slate-600 hover:border-slate-300'">B&W</button>
                            </div>
                        </div>

                        {{-- Scale Factor --}}
                        <div>
                            <label class="text-sm font-semibold text-slate-700 mb-1.5 block">
                                Scale <span class="font-normal text-slate-400" x-text="printScale + '%'"></span>
                            </label>
                            <div class="flex items-center gap-2">
                                <input type="range" x-model.number="printScale" min="25" max="200" step="5"
                                    class="flex-1 accent-[#287d3c] h-2 rounded-lg">
                                <button type="button" @click="printScale = 100"
                                    class="text-[10px] text-[#287d3c] font-bold hover:underline shrink-0">Reset</button>
                            </div>
                        </div>

                        {{-- Paper Type --}}
                        <div>
                            <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Paper Type</label>
                            <select x-model="printMedia"
                                class="w-full rounded-xl border border-slate-200 text-sm py-2.5 px-3 bg-white focus:ring-2 focus:ring-[#287d3c] focus:outline-none">
                                @foreach ($mediaOptions as $val => $label)
                                    <option value="{{ $val }}">{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>

                        {{-- GSM --}}
                        <div>
                            <label class="text-sm font-semibold text-slate-700 mb-1.5 block">GSM</label>
                            <select x-model="printGsm"
                                class="w-full rounded-xl border border-slate-200 text-sm py-2.5 px-3 bg-white focus:ring-2 focus:ring-[#287d3c] focus:outline-none">
                                @foreach ($gsmOptions as $val => $label)
                                    <option value="{{ $val }}">{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="flex gap-3 mt-6">
                        <button type="button" @click="applyPaperSettings()"
                            class="flex-1 bg-[#287d3c] hover:bg-emerald-800 text-white font-bold py-2.5 rounded-xl text-sm transition">
                            Apply
                        </button>
                        <button type="button" @click="showPaperModal = false"
                            class="flex-1 border border-slate-200 text-slate-600 font-semibold py-2.5 rounded-xl text-sm hover:bg-slate-50 transition">
                            Cancel
                        </button>
                    </div>
                </div>
            </div>

        </div>
    </div>
    </div>
@endsection

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js"></script>
    <script>
        if (window['pdfjsLib']) {
            pdfjsLib.GlobalWorkerOptions.workerSrc =
                'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js';
        }

        var __ptInstance = null;

        function checkFlow(file, trays, trayDims) {
            let _pdf = null;
            let _inited = false;

            return {
                file,
                trays,
                trayDims,

                page: 1,
                pages: 0,
                dims: null,
                dpi: null,
                colorMode: null,
                fontsEmbedded: null,
                fontCount: 0,
                ready: false,
                pdfError: null,

                tray: (trays.find(t => !t.out) || trays[0])?.key,
                copies: 1,
                orientationAction: 'rotate',

                bridgeChecking: true,
                bridgeReady: false,
                bridgeVersion: null,
                printers: [],
                selectedPrinter: null,
                printing: false,
                printMsg: null,
                printMsgKind: 'info',

                showBridgeModal: false,
                showPaperModal: false,

                printPaperSize: '{{ array_key_first($sizeOptions) }}',
                printLandscape: false,
                printDuplex: 'simplex',
                printColor: true,
                printScale: 100,
                printMargins: 'default',

                sizeOptionsMap: @json($sizeOptions),
                duplexOptions: [
                    { value: 'simplex', label: 'Off (single-sided)' },
                    { value: 'longEdge', label: 'Long edge (book-style)' },
                    { value: 'shortEdge', label: 'Short edge (tablet-style)' },
                ],
                marginOptions: [
                    { value: 'default', label: 'Default' },
                    { value: 'none', label: 'None (borderless)' },
                    { value: 'printableArea', label: 'Minimum (printable area)' },
                ],

                printMedia: '{{ array_key_first($mediaOptions) }}',
                printGsm: '{{ array_key_first($gsmOptions) }}',
                mediaOptionsMap: @json($mediaOptions),
                gsmOptionsMap: @json($gsmOptions),

                async init() {
                    if (_inited) return;
                    _inited = true;
                    if (file.type === 'image') {
                        await this.initImage();
                    } else {
                        await this.initPdf();
                    }
                    if (this.dims) this.printLandscape = this.dims.w > this.dims.h;
                    this.initBridge();
                },

                async initBridge() {
                    try {
                        const { PrintTrays } = await import('{{ asset("js/printtrays.js") }}');
                        const pp = new PrintTrays({
                            downloadUrl: 'https://noritsucanada.com/print-trays/download/',
                            onNotInstalled: () => {},
                        });
                        await pp.connect();
                        __ptInstance = pp;
                        this.bridgeReady = true;
                        this.bridgeVersion = pp.version || null;

                        const list = await pp.getPrinters();
                        const all = Array.isArray(list) ? list : [list].filter(Boolean);
                        const noritsu = all.filter(p => /noritsu/i.test(p.name));
                        const trayOrder = ['MP Tray', 'Tray 1', 'Tray 2', 'Tray 3', 'Tray 4', 'Tray 5'];
                        noritsu.sort((a, b) => {
                            const ai = trayOrder.findIndex(t => a.name.includes(t));
                            const bi = trayOrder.findIndex(t => b.name.includes(t));
                            return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
                        });
                        this.printers = noritsu;
                        if (this.printers.length > 0) this.selectedPrinter = this.printers[0].name;
                    } catch (e) {
                        console.warn('[localprint] PrintTrays connection failed:', e.message || e);
                        this.bridgeReady = false;
                    }
                    this.bridgeChecking = false;
                    if (!this.bridgeReady) this.showBridgeModal = true;
                },

                get selectedPrinterInfo() {
                    return this.printers.find(p => p.name === this.selectedPrinter) || null;
                },

                get printSettingsSummary() {
                    const parts = [this.sizeOptionsMap[this.printPaperSize] || this.printPaperSize];
                    parts.push(this.printLandscape ? 'Landscape' : 'Portrait');
                    if (this.printDuplex !== 'simplex') parts.push(this.printDuplex === 'longEdge' ? 'Duplex' : 'Duplex (short)');
                    parts.push(this.printColor ? 'Color' : 'B&W');
                    if (this.printScale !== 100) parts.push(this.printScale + '%');
                    if (this.printMargins !== 'default') parts.push(this.printMargins === 'none' ? 'Borderless' : 'Min margins');
                    parts.push(this.mediaOptionsMap[this.printMedia] || this.printMedia);
                    return parts.join(' · ');
                },

                selectPrinter(p) {
                    if (this.selectedPrinter !== p) {
                        this.selectedPrinter = p;
                        this.showPaperModal = true;
                    }
                },

                applyPaperSettings() {
                    this.showPaperModal = false;
                },

                async initImage() {
                    try {
                        const img = new Image();
                        img.crossOrigin = 'anonymous';
                        await new Promise((resolve, reject) => {
                            img.onload = resolve;
                            img.onerror = () => reject(new Error('Failed to load image'));
                            img.src = file.url;
                        });
                        this.dims = {
                            w: img.naturalWidth / 300,
                            h: img.naturalHeight / 300
                        };
                        this.pages = 1;
                        this.colorMode = 'RGB';
                        this.fontsEmbedded = true;
                        this.fontCount = 0;
                        this.ready = true;
                    } catch (e) {
                        this.pdfError = 'Could not load this image.';
                        this.ready = true;
                    }
                },

                async initPdf() {
                    if (!window['pdfjsLib']) {
                        this.pdfError = 'PDF viewer failed to load.';
                        this.ready = true;
                        return;
                    }
                    try {
                        const res = await fetch(file.url, {
                            credentials: 'same-origin'
                        });
                        if (!res.ok) throw new Error('HTTP ' + res.status + ' fetching ' + file.url);
                        const bytes = new Uint8Array(await res.arrayBuffer());

                        _pdf = await pdfjsLib.getDocument({
                            data: bytes
                        }).promise;
                        this.pages = _pdf.numPages;

                        const first = await _pdf.getPage(1);
                        const vp = first.getViewport({
                            scale: 1
                        });
                        this.dims = {
                            w: vp.width / 72,
                            h: vp.height / 72
                        };

                        await this.introspectPage(first);
                        this.ready = true;

                        this.$nextTick(() => this.renderPage(1));
                    } catch (e) {
                        console.error('[localprint] PDF read failed:', e);
                        this.pdfError = (e && e.message) ? ('Could not read this PDF: ' + e.message) :
                            'Could not read this PDF.';
                        this.ready = true;
                    }
                },

                async introspectPage(page) {
                    try {
                        const ops = await page.getOperatorList();
                        const fnMap = pdfjsLib.OPS;
                        let usesRGB = false,
                            usesCMYK = false,
                            usesGray = false;
                        for (let i = 0; i < ops.fnArray.length; i++) {
                            const fn = ops.fnArray[i];
                            if (fn === fnMap.setFillRGBColor || fn === fnMap.setStrokeRGBColor) usesRGB = true;
                            if (fn === fnMap.setFillCMYKColor || fn === fnMap.setStrokeCMYKColor) usesCMYK = true;
                            if (fn === fnMap.setFillGray || fn === fnMap.setStrokeGray) usesGray = true;
                        }
                        this.colorMode = usesCMYK ? 'CMYK' : (usesRGB ? 'RGB' : (usesGray ? 'Grayscale' : 'RGB'));

                        const tc = await page.getTextContent();
                        const fontIds = new Set();
                        for (const item of (tc.items || []))
                            if (item.fontName) fontIds.add(item.fontName);
                        this.fontCount = fontIds.size;
                        this.fontsEmbedded = fontIds.size === 0 ? false : true;
                    } catch (e) {
                        /* leave fields as null */
                    }
                },

                async renderPage(num) {
                    if (!_pdf) return;
                    const pg = await _pdf.getPage(num);
                    const scale = 2;
                    const vp = pg.getViewport({
                        scale
                    });
                    const canvas = this.$refs.pdfCanvas;
                    if (!canvas) return;
                    canvas.width = vp.width;
                    canvas.height = vp.height;
                    await pg.render({
                        canvasContext: canvas.getContext('2d'),
                        viewport: vp
                    }).promise;
                },

                nextPage() {
                    if (this.page < this.pages) {
                        this.page++;
                        this.renderPage(this.page);
                    }
                },
                prevPage() {
                    if (this.page > 1) {
                        this.page--;
                        this.renderPage(this.page);
                    }
                },

                // ── Derived state ──────────────────────────────

                get selectedTray() {
                    return this.trays.find(t => t.key === this.tray);
                },

                get trayMedia() {
                    const t = this.selectedTray;
                    if (!t || !t.size) return null;
                    const d = this.trayDims[t.size];
                    if (!d) return null;
                    return {
                        w: d.w,
                        h: d.h,
                        size: t.size
                    };
                },

                get orientation() {
                    if (!this.dims) return null;
                    return this.dims.w > this.dims.h ? 'landscape' : (this.dims.h > this.dims.w ? 'portrait' :
                        'square');
                },

                get trayOrientation() {
                    const m = this.trayMedia;
                    if (!m) return null;
                    return m.w > m.h ? 'landscape' : (m.h > m.w ? 'portrait' : 'square');
                },

                get orientationCheck() {
                    if (!this.dims || !this.trayMedia) return null;
                    const ok = this.orientation === this.trayOrientation || this.orientation === 'square' || this
                        .trayOrientation === 'square';
                    return {
                        ok,
                        detail: ok ?
                            'File and media orient the same way.' :
                            `The file is ${this.orientation}. The selected media (${this.trayMedia.size.replace('x', ' × ')}) is ${this.trayOrientation}.`,
                    };
                },

                get trimSize() {
                    const m = this.trayMedia;
                    if (!this.dims) return null;
                    if (!m) return this.dims;
                    const df = (this.orientation === this.trayOrientation) ? this.dims : {
                        w: this.dims.h,
                        h: this.dims.w
                    };
                    return df;
                },

                get sizeCheck() {
                    if (!this.dims || !this.trayMedia) {
                        return {
                            key: 'size',
                            ok: !!this.dims,
                            severity: 'warn',
                            title: 'Size',
                            detail: this.dims ? 'Select a print size.' : 'Reading page size…'
                        };
                    }
                    const df = this.trimSize;
                    const m = this.trayMedia;
                    const bleedW = Math.max(0, (df.w - m.w) / 2);
                    const bleedH = Math.max(0, (df.h - m.h) / 2);
                    const withinTrim = Math.abs(df.w - m.w) < 0.06 && Math.abs(df.h - m.h) < 0.06;
                    const withinBleed = df.w >= m.w && df.h >= m.h && df.w - m.w <= 0.5 && df.h - m.h <= 0.5;
                    if (withinTrim) {
                        return {
                            key: 'size',
                            ok: true,
                            severity: 'ok',
                            title: 'Size matches the media',
                            detail: `${this.fmt(m.w)} × ${this.fmt(m.h)} in trim.`
                        };
                    }
                    if (withinBleed) {
                        return {
                            key: 'size',
                            ok: true,
                            severity: 'ok',
                            title: 'Size matches the media',
                            detail: `${this.fmt(m.w)} × ${this.fmt(m.h)} in trimmed, ${this.fmt(Math.max(bleedW, bleedH))} in bleed on all sides.`
                        };
                    }
                    const bigger = df.w > m.w || df.h > m.h;
                    return {
                        key: 'size',
                        ok: false,
                        severity: 'warn',
                        title: 'Size does not match the media',
                        detail: `File is ${this.fmt(df.w)} × ${this.fmt(df.h)} in, media is ${this.fmt(m.w)} × ${this.fmt(m.h)} in.` +
                            (bigger ? ' The printer will crop the excess.' : ' The printer will scale to fit.'),
                    };
                },

                get resolutionCheck() {
                    if (!this.dims || !this.trayMedia) return {
                        key: 'res',
                        ok: false,
                        severity: 'warn',
                        title: 'Resolution',
                        detail: 'Chech the paper type.'
                    };
                    const df = this.trimSize;
                    const eff = Math.round(300 * Math.min(this.trayMedia.w / df.w, this.trayMedia.h / df.h));
                    this.dpi = eff;
                    if (eff >= 250) return {
                        key: 'res',
                        ok: true,
                        severity: 'ok',
                        title: 'Resolution is high enough',
                        detail: `${eff} dpi at final size.`
                    };
                    return {
                        key: 'res',
                        ok: false,
                        severity: 'warn',
                        title: 'Resolution is low',
                        detail: `${eff} dpi at final size. Print may look soft.`
                    };
                },

                get fontCheck() {
                    if (this.fontsEmbedded === null) {
                        return {
                            key: 'font',
                            ok: false,
                            severity: 'warn',
                            title: 'Fonts',
                            detail: 'Checking fonts…'
                        };
                    }
                    if (this.fontCount === 0) {
                        return {
                            key: 'font',
                            ok: true,
                            severity: 'ok',
                            title: 'GSM',
                            detail: 'Check the GSM'
                        };
                    }
                    return {
                        key: 'font',
                        ok: true,
                        severity: 'ok',
                        title: 'Fonts are embedded',
                        detail: `${this.fontCount} font${this.fontCount === 1 ? '' : 's'} found in the file.`
                    };
                },

                get checks() {
                    if (!this.ready || this.pdfError) return [];
                    const list = [this.sizeCheck, this.resolutionCheck];
                    if (this.file.type === 'pdf') list.push(this.fontCheck);
                    return list;
                },

                get canPrint() {
                    if (!this.ready || this.pdfError) return false;
                    if (this.copies < 1) return false;
                    if (this.bridgeReady) return !!this.selectedPrinter;
                    if (!this.selectedTray || this.selectedTray.out) return false;
                    return true;
                },

                get blocker() {
                    if (!this.ready) return 'Reading file…';
                    if (this.pdfError) return 'Fix the file to continue';
                    if (this.bridgeChecking) return 'Connecting to PrintTrays…';
                    if (this.bridgeReady && !this.selectedPrinter) return 'Select a printer';
                    if (!this.bridgeReady && (!this.selectedTray || this.selectedTray.out)) return 'Choose a loaded tray';
                    if (!this.bridgeReady) return 'PrintTrays not connected';
                    return null;
                },

                async doPrint() {
                    if (!this.canPrint || this.printing) return;
                    this.printing = true;
                    this.printMsg = 'Sending to printer…';
                    this.printMsgKind = 'info';

                    try {
                        const pp = __ptInstance;
                        if (!pp) throw new Error('PrintTrays not connected');

                        const res = await fetch(this.file.url, { credentials: 'same-origin' });
                        if (!res.ok) throw new Error('Failed to fetch file: HTTP ' + res.status);
                        const b64 = this.arrayBufToBase64(await res.arrayBuffer());

                        let data = b64;
                        if (this.file.type === 'image') {
                            const ext = this.file.name.split('.').pop().toLowerCase();
                            if (['webp', 'tiff', 'tif'].includes(ext)) {
                                data = await this.imageToBase64Png(this.file.url);
                            }
                        }

                        const printOpts = {
                            type: 'pdf',
                            encoding: 'base64',
                            copies: this.copies || 1,
                            paperSize: this.printPaperSize,
                            color: this.printColor,
                            scaleFactor: this.printScale,
                        };

                        if (this.printLandscape) printOpts.landscape = true;
                        if (this.printDuplex !== 'simplex') printOpts.duplex = this.printDuplex;
                        if (this.printMargins !== 'default') printOpts.margins = { marginType: this.printMargins };

                        await pp.print(this.selectedPrinter, data, printOpts);
                        this.printMsg = 'Sent to ' + this.selectedPrinter + '!';
                        this.printMsgKind = 'success';
                    } catch (e) {
                        console.error('[localprint] PrintTrays print failed:', e);
                        this.printMsg = (e && e.message) || 'Print failed.';
                        this.printMsgKind = 'error';
                    } finally {
                        this.printing = false;
                    }
                },

                imageToBase64Png(url) {
                    return new Promise((resolve, reject) => {
                        const img = new Image();
                        img.crossOrigin = 'anonymous';
                        img.onload = () => {
                            const c = document.createElement('canvas');
                            c.width = img.naturalWidth;
                            c.height = img.naturalHeight;
                            c.getContext('2d').drawImage(img, 0, 0);
                            resolve(c.toDataURL('image/png').split(',')[1]);
                        };
                        img.onerror = () => reject(new Error('Failed to load image for conversion'));
                        img.src = url;
                    });
                },

                arrayBufToBase64(buf) {
                    const bytes = new Uint8Array(buf);
                    let binary = '';
                    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
                    return btoa(binary);
                },

                fmt(n) {
                    return (Math.round(n * 100) / 100).toFixed(2).replace(/\.00$/, '');
                },
                prettySize(bytes) {
                    if (!bytes) return '';
                    const kb = bytes / 1024;
                    return kb < 1024 ? `${kb.toFixed(0)} KB` : `${(kb / 1024).toFixed(1)} MB`;
                },
            };
        }
    </script>
@endpush
