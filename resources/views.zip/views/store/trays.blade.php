@extends('layouts.store')
@section('title', 'Trays')

@section('content')
    <a href="{{ route('storepanel.orders') }}"
        class="inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-800 transition mb-6">
        <i data-lucide="arrow-left" class="w-4 h-4"></i> Back
    </a>

    <h1 class="font-display font-bold text-2xl md:text-4xl text-slate-900 tracking-tight">What is loaded in each printer</h1>

    @if (session('success'))
        <div
            class="mt-5 max-w-2xl px-4 py-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-medium">
            {{ session('success') }}</div>
    @endif
    @if (session('warning'))
        <div
            class="mt-5 max-w-2xl px-4 py-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-sm font-medium">
            {{ session('warning') }}</div>
    @endif

    <form method="POST" action="{{ route('storepanel.trays.save') }}" class="mt-8 max-w-3xl" x-data="trayForm({{ Illuminate\Support\Js::from($rows) }}, {{ Illuminate\Support\Js::from($sizeOptions) }}, {{ Illuminate\Support\Js::from($sizeDims) }})"
        x-init="scan()">
        @csrf

        {{-- Scan status --}}
        <div class="mb-4 flex items-center gap-3">
            <span class="text-[11px] font-black uppercase tracking-widest text-slate-400">Noritsu Printers</span>
            <span x-show="scanState === 'loading'" class="text-[12px] text-slate-400 flex items-center gap-2">
                <svg class="animate-spin w-3.5 h-3.5" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4">
                    </circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                </svg>
                Scanning printers…
            </span>
            <span x-show="scanState === 'ok'" class="mono text-[11px] text-slate-500"
                x-text="rows.length + ' printer' + (rows.length === 1 ? '' : 's')"></span>
            <button type="button" @click="scan()" x-show="scanState !== 'loading'"
                class="ml-auto inline-flex items-center gap-1.5 text-[12px] font-semibold text-slate-500 hover:text-slate-800 transition">
                <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i> Rescan
            </button>
        </div>

        {{-- PrintTrays missing hint --}}
        <div x-show="scanState === 'error'"
            class="mb-4 flex items-center gap-3 px-4 py-3 rounded-2xl bg-amber-50 border border-amber-200">
            <i data-lucide="printer-off" class="w-4 h-4 text-amber-600 shrink-0"></i>
            <p class="text-[13px] text-amber-800 leading-snug flex-1">
                PrintTrays isn't running on this PC. Install it and reload to detect printers.
            </p>
            <a href="https://noritsucanada.com/print-trays/download/" target="_blank" rel="noopener"
                class="shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#287d3c] hover:bg-emerald-800 text-white text-[12px] font-bold transition">
                <i data-lucide="download" class="w-3.5 h-3.5"></i>
                Download PrintTrays
            </a>
        </div>

        {{-- Empty state --}}
        <div x-show="scanState === 'ok' && rows.length === 0"
            class="mb-4 px-4 py-6 rounded-2xl bg-slate-50 border border-slate-200 text-center text-[13px] text-slate-500">
            No Noritsu printers found on this PC.
        </div>

        {{-- Printer rows --}}
        <div class="space-y-2">
            <template x-for="(row, i) in rows" :key="row.key">
                <div class="bg-white border border-slate-200/80 rounded-2xl p-4 cursor-pointer transition hover:border-slate-300"
                    :class="row.enabled ? '' : 'opacity-60'"
                    @click="openConfig(i)">

                    <div class="flex items-center gap-3">
                        {{-- Enable toggle --}}
                        <button type="button" @click.stop="row.enabled = !row.enabled" role="switch"
                            :aria-checked="row.enabled" class="relative w-11 h-6 rounded-full transition-colors shrink-0"
                            :class="row.enabled ? 'bg-[#287d3c]' : 'bg-slate-300'">
                            <span
                                class="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform"
                                :class="row.enabled ? 'translate-x-5' : ''"></span>
                        </button>

                        <div class="flex-1 min-w-0">
                            <p class="font-bold text-[14px] text-slate-900 truncate" x-text="row.label" :title="row.label"></p>
                            <p class="mono text-[11px] text-slate-400 mt-0.5">
                                <span x-text="row.printer"></span>
                                <span x-show="row.defaultPrinter" class="ml-1 text-blue-600 font-bold">· default</span>
                            </p>
                        </div>

                        <button type="button" @click.stop="openConfig(i)"
                            class="text-[11px] text-[#287d3c] font-bold hover:underline shrink-0">Change</button>
                    </div>

                    {{-- Saved params summary --}}
                    <template x-if="row.size || row.media || row.gsm">
                        <div class="mt-2 ml-14 flex flex-wrap items-center gap-1.5">
                            <template x-if="row.size">
                                <span class="inline-flex items-center px-2 py-0.5 text-[10px] font-semibold rounded-md bg-slate-100 text-slate-600 border border-slate-200" x-text="sizeLabel(row)"></span>
                            </template>
                            <span class="inline-flex items-center px-2 py-0.5 text-[10px] font-semibold rounded-md bg-slate-100 text-slate-600 border border-slate-200" x-text="row.landscape ? 'Landscape' : 'Portrait'"></span>
                            <template x-if="row.duplex !== 'simplex'">
                                <span class="inline-flex items-center px-2 py-0.5 text-[10px] font-semibold rounded-md bg-slate-100 text-slate-600 border border-slate-200" x-text="row.duplex === 'longEdge' ? 'Duplex' : 'Duplex (short)'"></span>
                            </template>
                            <span class="inline-flex items-center px-2 py-0.5 text-[10px] font-semibold rounded-md bg-slate-100 text-slate-600 border border-slate-200" x-text="row.color ? 'Color' : 'B&W'"></span>
                            <template x-if="row.scale !== 100">
                                <span class="inline-flex items-center px-2 py-0.5 text-[10px] font-semibold rounded-md bg-slate-100 text-slate-600 border border-slate-200" x-text="row.scale + '%'"></span>
                            </template>
                            <template x-if="row.margins !== 'default'">
                                <span class="inline-flex items-center px-2 py-0.5 text-[10px] font-semibold rounded-md bg-slate-100 text-slate-600 border border-slate-200" x-text="row.margins === 'none' ? 'Borderless' : 'Min margins'"></span>
                            </template>
                            <template x-if="row.media">
                                <span class="inline-flex items-center px-2 py-0.5 text-[10px] font-semibold rounded-md bg-slate-100 text-slate-600 border border-slate-200" x-text="mediaLabel(row.media)"></span>
                            </template>
                            <template x-if="row.gsm">
                                <span class="inline-flex items-center px-2 py-0.5 text-[10px] font-semibold rounded-md bg-slate-100 text-slate-600 border border-slate-200" x-text="gsmLabel(row.gsm)"></span>
                            </template>
                            <template x-if="row.density">
                                <span class="inline-flex items-center px-2 py-0.5 text-[10px] font-semibold rounded-md bg-slate-100 text-slate-600 border border-slate-200" x-text="row.density + ' dpi'"></span>
                            </template>
                            <span class="text-[10px] text-slate-400 ml-1">UT<span x-text="userType(row) ?? '-'"></span></span>
                        </div>
                    </template>

                    {{-- Loading indicator --}}
                    <div x-show="row.detailsLoading" class="mt-2 ml-14">
                        <span class="text-[11px] text-slate-400 flex items-center gap-1.5">
                            <svg class="animate-spin w-3 h-3" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                            </svg>
                            Reading printer capabilities…
                        </span>
                    </div>

                    {{-- Hidden fields --}}
                    <input type="hidden" :name="`trays[${i}][printer]`" :value="row.printer">
                    <input type="hidden" :name="`trays[${i}][enabled]`" :value="row.enabled ? 1 : 0">
                    <input type="hidden" :name="`trays[${i}][size]`" :value="row.size">
                    <input type="hidden" :name="`trays[${i}][media]`" :value="row.media">
                    <input type="hidden" :name="`trays[${i}][gsm]`" :value="row.gsm">
                    <input type="hidden" :name="`trays[${i}][density]`" :value="row.density">
                    <input type="hidden" :name="`trays[${i}][landscape]`" :value="row.landscape ? 1 : 0">
                    <input type="hidden" :name="`trays[${i}][duplex]`" :value="row.duplex">
                    <input type="hidden" :name="`trays[${i}][margins]`" :value="row.margins">
                    <input type="hidden" :name="`trays[${i}][color]`" :value="row.color ? 1 : 0">
                    <input type="hidden" :name="`trays[${i}][scale]`" :value="row.scale">
                    <input type="hidden" :name="`trays[${i}][size_width]`" :value="selectedPaperWidth(row)">
                    <input type="hidden" :name="`trays[${i}][size_height]`" :value="selectedPaperHeight(row)">
                </div>
            </template>
        </div>

        <div class="flex items-center gap-3 mt-8">
            <button type="submit" :disabled="rows.length === 0"
                class="px-5 py-2.5 rounded-xl bg-[#287d3c] hover:bg-emerald-800 text-white text-sm font-bold transition disabled:bg-slate-300 disabled:cursor-not-allowed">
                Save tray setup
            </button>
            <a href="{{ route('storepanel.orders') }}"
                class="px-5 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm font-semibold hover:bg-slate-50 transition">Cancel</a>
        </div>
    </form>

    {{-- Configuration modal --}}
    <div x-data x-show="$store.trayModal.visible" x-cloak class="fixed inset-0 z-[90] flex items-center justify-center p-4"
        @keydown.escape.window="$store.trayModal.visible = false">
        <div class="absolute inset-0 bg-black/40" @click="$store.trayModal.visible = false"></div>
        <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto p-6" @click.stop>
            <div class="flex items-center justify-between mb-5">
                <h3 class="font-bold text-slate-900 text-base">Print Settings</h3>
                <button type="button" @click="$store.trayModal.visible = false"
                    class="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>

            <div class="mb-4">
                <p class="text-[12px] text-slate-500">
                    Configuring <span class="font-bold text-slate-700" x-text="$store.trayModal.label"></span>
                </p>
                <p class="text-[11px] mt-0.5" x-show="$store.trayModal.driver"
                    :class="'text-slate-400'"
                    x-text="$store.trayModal.driver"></p>
                <p class="text-[11px] mt-0.5 text-emerald-600" x-show="$store.trayModal.status"
                    x-text="'Status: ' + $store.trayModal.status"></p>
            </div>

            <div class="grid grid-cols-2 gap-x-3 gap-y-4">
                {{-- Paper Size --}}
                <div>
                    <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Paper Size</label>
                    <select x-model="$store.trayModal.size"
                        class="w-full rounded-xl border border-slate-200 text-sm py-2.5 px-3 bg-white focus:ring-2 focus:ring-[#287d3c] focus:outline-none">
                        <option value="">Size…</option>
                        <template x-for="opt in $store.trayModal.sizeOptions" :key="opt.name">
                            <option :value="opt.name" x-text="opt.label"></option>
                        </template>
                    </select>
                </div>

                {{-- Orientation --}}
                <div>
                    <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Orientation</label>
                    <div class="flex gap-1.5">
                        <button type="button" @click="$store.trayModal.landscape = false"
                            class="flex-1 flex items-center justify-center gap-1 mono text-[11px] px-2 py-2.5 rounded-lg border transition"
                            :class="!$store.trayModal.landscape ? 'border-[#287d3c] text-[#287d3c] bg-[#f2f7f2] font-bold' :
                                'border-slate-200 text-slate-600 hover:border-slate-300'">
                            <svg class="w-3.5 h-[18px] shrink-0" viewBox="0 0 16 20" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="1" width="12" height="18" rx="1.5"/></svg>
                            Portrait
                        </button>
                        <button type="button" @click="$store.trayModal.landscape = true"
                            class="flex-1 flex items-center justify-center gap-1 mono text-[11px] px-2 py-2.5 rounded-lg border transition"
                            :class="$store.trayModal.landscape ? 'border-[#287d3c] text-[#287d3c] bg-[#f2f7f2] font-bold' :
                                'border-slate-200 text-slate-600 hover:border-slate-300'">
                            <svg class="w-[18px] h-3.5 shrink-0" viewBox="0 0 20 16" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="1" y="2" width="18" height="12" rx="1.5"/></svg>
                            Landscape
                        </button>
                    </div>
                </div>

                {{-- Duplex --}}
                <div>
                    <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Duplex</label>
                    <select x-model="$store.trayModal.duplex"
                        class="w-full rounded-xl border border-slate-200 text-sm py-2.5 px-3 bg-white focus:ring-2 focus:ring-[#287d3c] focus:outline-none">
                        <option value="simplex">Off (single-sided)</option>
                        <option value="longEdge">Long edge (book-style)</option>
                        <option value="shortEdge">Short edge (tablet-style)</option>
                    </select>
                </div>

                {{-- Margins --}}
                <div>
                    <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Margins</label>
                    <select x-model="$store.trayModal.margins"
                        class="w-full rounded-xl border border-slate-200 text-sm py-2.5 px-3 bg-white focus:ring-2 focus:ring-[#287d3c] focus:outline-none">
                        <option value="default">Default</option>
                        <option value="none">None (borderless)</option>
                        <option value="printableArea">Minimum (printable area)</option>
                    </select>
                </div>

                {{-- Color Mode --}}
                <div>
                    <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Color</label>
                    <div class="flex gap-1.5">
                        <button type="button" @click="$store.trayModal.color = true"
                            class="flex-1 mono text-[11px] px-2 py-2.5 rounded-lg border transition text-center"
                            :class="$store.trayModal.color ? 'border-[#287d3c] text-[#287d3c] bg-[#f2f7f2] font-bold' :
                                'border-slate-200 text-slate-600 hover:border-slate-300'">Color</button>
                        <button type="button" @click="$store.trayModal.color = false"
                            class="flex-1 mono text-[11px] px-2 py-2.5 rounded-lg border transition text-center"
                            :class="!$store.trayModal.color ? 'border-[#287d3c] text-[#287d3c] bg-[#f2f7f2] font-bold' :
                                'border-slate-200 text-slate-600 hover:border-slate-300'">B&W</button>
                    </div>
                </div>

                {{-- Scale Factor --}}
                <div>
                    <label class="text-sm font-semibold text-slate-700 mb-1.5 block">
                        Scale <span class="font-normal text-slate-400" x-text="$store.trayModal.scale + '%'"></span>
                    </label>
                    <div class="flex items-center gap-2">
                        <input type="range" x-model.number="$store.trayModal.scale" min="25" max="200" step="5"
                            class="flex-1 accent-[#287d3c] h-2 rounded-lg">
                        <button type="button" @click="$store.trayModal.scale = 100"
                            class="text-[10px] text-[#287d3c] font-bold hover:underline shrink-0">Reset</button>
                    </div>
                </div>

                {{-- Paper Type --}}
                <div>
                    <label class="text-sm font-semibold text-slate-700 mb-1.5 block">Paper Type</label>
                    <select x-model="$store.trayModal.media"
                        class="w-full rounded-xl border border-slate-200 text-sm py-2.5 px-3 bg-white focus:ring-2 focus:ring-[#287d3c] focus:outline-none">
                        <option value="">Paper…</option>
                        @foreach ($mediaOptions as $val => $label)
                            <option value="{{ $val }}">{{ $label }}</option>
                        @endforeach
                    </select>
                </div>

                {{-- GSM --}}
                <div>
                    <label class="text-sm font-semibold text-slate-700 mb-1.5 block">GSM</label>
                    <select x-model="$store.trayModal.gsm"
                        class="w-full rounded-xl border border-slate-200 text-sm py-2.5 px-3 bg-white focus:ring-2 focus:ring-[#287d3c] focus:outline-none">
                        <option value="">gsm…</option>
                        @foreach ($gsmOptions as $val => $label)
                            <option value="{{ $val }}">{{ $label }}</option>
                        @endforeach
                    </select>
                </div>

                {{-- DPI --}}
                <template x-if="$store.trayModal.densityOptions.length > 0">
                    <div>
                        <label class="text-sm font-semibold text-slate-700 mb-1.5 block">DPI</label>
                        <select x-model="$store.trayModal.density"
                            class="w-full rounded-xl border border-slate-200 text-sm py-2.5 px-3 bg-white focus:ring-2 focus:ring-[#287d3c] focus:outline-none">
                            <option value="">DPI…</option>
                            <template x-for="d in $store.trayModal.densityOptions" :key="d.value">
                                <option :value="d.value" x-text="d.label"></option>
                            </template>
                        </select>
                    </div>
                </template>
            </div>

            <div class="flex gap-3 mt-6">
                <button type="button" @click="$store.trayModal.apply()"
                    class="flex-1 bg-[#287d3c] hover:bg-emerald-800 text-white font-bold py-2.5 rounded-xl text-sm transition">
                    Apply
                </button>
                <button type="button" @click="$store.trayModal.visible = false"
                    class="flex-1 border border-slate-200 text-slate-600 font-semibold py-2.5 rounded-xl text-sm hover:bg-slate-50 transition">
                    Cancel
                </button>
            </div>
        </div>
    </div>

    {{-- PrintTrays onboarding modal --}}
    @if ($needsQzOnboarding ?? false)
        <div x-data="bridgeOnboarding()" x-init="visible = true" x-cloak x-show="visible"
            class="fixed inset-0 z-[95] flex items-center justify-center px-4">
            <div class="absolute inset-0 bg-slate-900/60"></div>

            <div class="relative bg-white border border-slate-200 rounded-2xl shadow-2xl w-full max-w-md p-6" @click.stop>
                <div class="flex items-start gap-3">
                    <div
                        class="w-10 h-10 rounded-full bg-[#eaf3ea] border border-[#bfdcc4] flex items-center justify-center shrink-0">
                        <i data-lucide="printer" class="w-5 h-5 text-[#287d3c]"></i>
                    </div>
                    <div class="flex-1">
                        <h3 class="font-display font-bold text-lg text-slate-900">Do you have PrintTrays installed?</h3>
                        <p class="text-[13px] text-slate-600 mt-1 leading-relaxed">
                            PrintTrays is the local printer bridge that lets this PC
                            print to the Noritsu 931-BL. If it's already installed,
                            confirm below - we'll remember it for your next visit.
                        </p>

                        <div class="mt-5 flex items-center gap-2 flex-wrap">
                            <a href="https://noritsucanada.com/print-trays/download/" target="_blank" rel="noopener"
                                class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#287d3c] hover:bg-emerald-800 text-white text-sm font-bold transition">
                                <i data-lucide="download" class="w-4 h-4"></i>
                                Download PrintTrays
                            </a>
                            <button type="button" @click="confirm()" :disabled="saving"
                                class="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 text-sm font-semibold hover:bg-slate-50 transition disabled:opacity-60 disabled:cursor-not-allowed">
                                <i data-lucide="check" class="w-4 h-4"></i>
                                <span x-show="!saving">Already Downloaded</span>
                                <span x-show="saving">Saving…</span>
                            </button>
                        </div>

                        <p x-show="error" x-text="error" class="text-[12px] text-red-600 font-medium mt-3"></p>
                    </div>
                </div>
            </div>
        </div>
    @endif
@endsection

@push('scripts')
    <script>
        var __ptInstance = null;

        function bridgeOnboarding() {
            return {
                visible: false,
                saving: false,
                error: '',
                async confirm() {
                    if (this.saving) return;
                    this.saving = true;
                    this.error = '';
                    const csrf = document.querySelector('meta[name="csrf-token"]')?.content ||
                        document.querySelector('input[name="_token"]')?.value;
                    try {
                        const res = await fetch("{{ route('storepanel.qz.confirm') }}", {
                            method: 'POST',
                            credentials: 'same-origin',
                            headers: {
                                'Accept': 'application/json',
                                'X-CSRF-TOKEN': csrf,
                            },
                        });
                        if (!res.ok) throw new Error('HTTP ' + res.status);
                        this.visible = false;
                    } catch (e) {
                        this.error = 'Could not save. Please try again.';
                    } finally {
                        this.saving = false;
                    }
                },
            };
        }

        function slugKey(name) {
            return String(name || '')
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, '_')
                .replace(/^_+|_+$/g, '') || 'printer';
        }

        // Alpine global store for the config modal
        document.addEventListener('alpine:init', () => {
            Alpine.store('trayModal', {
                visible: false,
                rowIndex: null,
                label: '',
                driver: '',
                status: '',
                size: '',
                media: '',
                gsm: '',
                density: '',
                landscape: false,
                duplex: 'simplex',
                margins: 'default',
                color: true,
                scale: 100,
                sizeOptions: [],
                densityOptions: [],
                _applyCallback: null,

                apply() {
                    if (this._applyCallback) {
                        this._applyCallback(this.rowIndex, {
                            size: this.size,
                            media: this.media,
                            gsm: this.gsm,
                            density: this.density,
                            landscape: this.landscape,
                            duplex: this.duplex,
                            margins: this.margins,
                            color: this.color,
                            scale: this.scale,
                        });
                    }
                    this.visible = false;
                },
            });
        });

        function trayForm(savedRows, serverSizeOptions, serverSizeDims) {
            const savedByKey = {};
            (savedRows || []).forEach(r => {
                if (r && r.key) savedByKey[r.key] = r;
            });

            const STATIC_SIZES = Object.entries(serverSizeOptions || {}).map(([code, label]) => {
                const dims = (serverSizeDims || {})[code];
                return {
                    name: code,
                    label,
                    width: dims ? dims[0] : null,
                    height: dims ? dims[1] : null
                };
            });

            const KNOWN_DIMS = serverSizeDims || {};

            const MEDIA_LABELS = @json($mediaOptions);
            const GSM_LABELS = @json($gsmOptions);

            function normalizeSizeCode(w, h) {
                if (!w || !h) return null;
                for (const [code, [cw, ch]] of Object.entries(KNOWN_DIMS)) {
                    if ((Math.abs(w - cw) < 0.15 && Math.abs(h - ch) < 0.15) ||
                        (Math.abs(w - ch) < 0.15 && Math.abs(h - cw) < 0.15)) return code;
                }
                return null;
            }

            const TRAY_ORDER = ['MP Tray', 'Tray 1', 'Tray 2', 'Tray 3', 'Tray 4', 'Tray 5'];

            return {
                rows: [],
                scanState: 'idle',
                defaultPrinter: null,
                staticSizes: STATIC_SIZES,

                openConfig(i) {
                    const row = this.rows[i];
                    if (!row) return;
                    const store = Alpine.store('trayModal');
                    store.rowIndex = i;
                    store.label = row.label;
                    store.driver = row.driver || '';
                    store.status = row.status || '';
                    store.size = row.size || '';
                    store.media = row.media || '';
                    store.gsm = row.gsm || '';
                    store.density = row.density || '';
                    store.landscape = row.landscape || false;
                    store.duplex = row.duplex || 'simplex';
                    store.margins = row.margins || 'default';
                    store.color = row.color !== undefined ? row.color : true;
                    store.scale = row.scale || 100;
                    store.sizeOptions = this.sizeOptionsFor(row);
                    store.densityOptions = row.densities || [];
                    store._applyCallback = (idx, vals) => {
                        const r = this.rows[idx];
                        if (!r) return;
                        r.size = vals.size;
                        r.media = vals.media;
                        r.gsm = vals.gsm;
                        r.density = vals.density;
                        r.landscape = vals.landscape;
                        r.duplex = vals.duplex;
                        r.margins = vals.margins;
                        r.color = vals.color;
                        r.scale = vals.scale;
                        this.onSizeChange(r);
                        if (!r.enabled && (vals.size || vals.media || vals.gsm)) r.enabled = true;
                    };
                    store.visible = true;
                },

                sizeLabel(row) {
                    const opts = this.sizeOptionsFor(row);
                    const found = opts.find(o => o.name === row.size);
                    return found ? found.label : row.size;
                },

                mediaLabel(val) {
                    return MEDIA_LABELS[val] || val;
                },

                gsmLabel(val) {
                    return GSM_LABELS[val] || val;
                },

                async scan() {
                    this.scanState = 'loading';
                    try {
                        const { PrintTrays } = await import('{{ asset("js/printtrays.js") }}');
                        const pp = new PrintTrays({
                            downloadUrl: 'https://noritsucanada.com/print-trays/download/',
                            onNotInstalled: () => {},
                        });
                        await pp.connect();
                        __ptInstance = pp;

                        const list = await pp.getPrinters();
                        const all = Array.isArray(list) ? list : [list].filter(Boolean);

                        this.defaultPrinter = (all.find(p => p.isDefault) || {}).name || null;

                        const noritsu = all.filter(p => /noritsu/i.test(p.name));
                        noritsu.sort((a, b) => {
                            const ai = TRAY_ORDER.findIndex(t => a.name.includes(t));
                            const bi = TRAY_ORDER.findIndex(t => b.name.includes(t));
                            return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
                        });

                        const seen = new Set();
                        this.rows = noritsu.map(p => {
                            const key = slugKey(p.name);
                            if (seen.has(key)) return null;
                            seen.add(key);
                            const prior = savedByKey[key] || {};
                            return {
                                key,
                                label: p.name,
                                printer: p.name,
                                driver: p.driver || '',
                                status: p.status || '',
                                defaultPrinter: p.name === this.defaultPrinter,
                                size: prior.size || '',
                                sizeWidth: prior.size_width || null,
                                sizeHeight: prior.size_height || null,
                                media: prior.media || '',
                                gsm: prior.gsm || '',
                                density: prior.density || '',
                                landscape: prior.landscape || false,
                                duplex: prior.duplex || 'simplex',
                                margins: prior.margins || 'default',
                                color: prior.color !== undefined ? prior.color : true,
                                scale: prior.scale || 100,
                                enabled: prior.enabled ?? false,
                                paperSizes: [],
                                densities: [],
                                detailsLoading: false,
                            };
                        }).filter(Boolean);
                        this.scanState = 'ok';
                    } catch (e) {
                        console.warn('[trays] PrintTrays connection failed:', e.message || e);
                        this.rows = [];
                        this.scanState = 'error';
                    }
                    this.$nextTick(() => {
                        if (window.lucide) lucide.createIcons();
                    });
                },

                sizeOptionsFor(row) {
                    if (row.paperSizes && row.paperSizes.length) return row.paperSizes;
                    return STATIC_SIZES;
                },

                onSizeChange(row) {
                    const ps = this.sizeOptionsFor(row).find(p => p.name === row.size);
                    row.sizeWidth = ps ? ps.width : null;
                    row.sizeHeight = ps ? ps.height : null;
                },

                selectedPaperWidth(row) {
                    const ps = this.sizeOptionsFor(row).find(p => p.name === row.size);
                    return ps ? ps.width : (row.sizeWidth || '');
                },

                selectedPaperHeight(row) {
                    const ps = this.sizeOptionsFor(row).find(p => p.name === row.size);
                    return ps ? ps.height : (row.sizeHeight || '');
                },

                userType(row) {
                    const { media, gsm } = row;
                    if (!media) return null;
                    if (media === 'film') return 7;
                    if (['envelopes', 'labels'].includes(media)) return 3;
                    if (media === 'magnets') return 6;
                    let ut = { '120': 1, '120-150': 2, '150-270': 5, '270-324': 6 }[gsm] ?? 1;
                    const scored = media === 'cardstock_scored';
                    const glossy = ['photo_glossy', 'photo_lustre'].includes(media);
                    const w = this.selectedPaperWidth(row);
                    const h = this.selectedPaperHeight(row);
                    const is5x7 = normalizeSizeCode(w, h) === '5x7';
                    if (scored) ut = (gsm === '270-324' && is5x7) ? 5 : 6;
                    if (glossy) ut = ({ 1: 2, 2: 5, 5: 6 })[ut] ?? ut;
                    return ut;
                },
            };
        }
    </script>
@endpush
